<?php

// bKash Order Debugger Main Class
class BkashOrderDebugger {
    
    // Constructor
    public function __construct() {
        add_action('admin_enqueue_scripts', array($this, 'enqueue_admin_scripts'));
    }
   
    // Enqueue admin scripts and styles
    public function enqueue_admin_scripts($hook) {
        if ($hook !== 'easypay_page_bkash-order-debugger') {
            return;
        }
        
        // Add JavaScript for modal functionality
        wp_add_inline_script('jquery', '
            jQuery(document).ready(function($) {
                // Modal functionality
                $(document).on("click", ".view-details-btn", function() {
                    var orderId = $(this).data("order-id");
                    $("#modal-" + orderId).show();
                });
                
                $(document).on("click", ".close-modal", function() {
                    $(this).closest(".bkash-modal").hide();
                });
                
                // Close modal when clicking outside
                $(document).on("click", ".bkash-modal", function(e) {
                    if ($(e.target).hasClass("bkash-modal")) {
                        $(this).hide();
                    }
                });
            });
        ');
        
        wp_add_inline_style('wp-admin', '.wrap{max-width:100%;background:#f2f2f7;margin:0;margin-right:20px}.wrap h1{font-size:34px;font-weight:700;color:#000;margin-bottom:20px;letter-spacing:-0.5px}.table-container{background:#fff;border-radius:12px;box-shadow:0 2px 10px rgba(0,0,0,0.08);overflow:hidden;margin-top:20px}.bkash-debugger-table{border-collapse:collapse;width:100%;font-size:14px;table-layout:fixed;margin:0}.bkash-debugger-table th,.bkash-debugger-table td{border:none;border-bottom:1px solid #e5e5ea;padding:12px 16px;text-align:left;vertical-align:top;word-wrap:break-word;overflow-wrap:break-word}.bkash-debugger-table th{background-color:#f9f9fb;font-weight:600;color:#8e8e93;font-size:13px;text-transform:uppercase;letter-spacing:0.5px}.bkash-debugger-table tr:last-child td{border-bottom:none}.bkash-debugger-table tr:hover{background-color:#f9f9fb}.bkash-debugger-table th:nth-child(1),.bkash-debugger-table td:nth-child(1){width:8%}.bkash-debugger-table th:nth-child(2),.bkash-debugger-table td:nth-child(2){width:12%}.bkash-debugger-table th:nth-child(3),.bkash-debugger-table td:nth-child(3){width:8%}.bkash-debugger-table th:nth-child(4),.bkash-debugger-table td:nth-child(4){width:12%}.bkash-debugger-table th:nth-child(5),.bkash-debugger-table td:nth-child(5){width:20%}.bkash-debugger-table th:nth-child(6),.bkash-debugger-table td:nth-child(6){width:20%}.bkash-debugger-table th:nth-child(7),.bkash-debugger-table td:nth-child(7){width:12%}.bkash-debugger-table th:nth-child(8),.bkash-debugger-table td:nth-child(8){width:8%}.details-container{font-size:13px;line-height:1.6}.detail-item{margin-bottom:6px;display:block}.detail-content{display:inline-block;padding:4px 10px;border-radius:6px;font-size:12px}.detail-label{font-weight:600;color:#3c3c43;opacity:0.6}.detail-value{color:#000}.detail-content.match-success{background:#d1f2d1;color:#00c851}.detail-content.match-fail{background:#ffd6d6;color:#ff3b30}.detail-content.no-data{background:#f2f2f7;color:#8e8e93;font-style:italic}.match-status{display:inline-block;padding:6px 12px;border-radius:8px;font-size:12px;font-weight:500}.match-status.all-match{background:#34c759;color:#fff}.match-status.partial-match{background:#ff9500;color:#fff}.match-status.no-match{background:#ff3b30;color:#fff}.match-status.no-sms{background:#c7c7cc;color:#fff}.bkash-modal{display:none;position:fixed;z-index:100000;left:0;top:0;width:100%;height:100%;overflow:auto;background-color:rgba(0,0,0,0.4);backdrop-filter:blur(10px);-webkit-backdrop-filter:blur(10px)}.bkash-modal-content{background-color:#fff;margin:5% auto;padding:0;width:90%;max-width:800px;border-radius:14px;box-shadow:0 10px 40px rgba(0,0,0,0.2);overflow:hidden}.modal-header{background:#f9f9fb;border-bottom:1px solid #e5e5ea;padding:20px;position:relative}.modal-header h2{margin:0;font-size:20px;font-weight:600;color:#000}.close-modal{position:absolute;right:20px;top:20px;width:30px;height:30px;background:#e5e5ea;border-radius:50%;display:flex;align-items:center;justify-content:center;cursor:pointer;font-size:20px;color:#8e8e93;line-height:1}.close-modal:hover{background:#d1d1d6;color:#000}.modal-section{padding:20px;border-bottom:1px solid #e5e5ea}.modal-section:last-child{border-bottom:none}.modal-section h3{margin:0 0 15px 0;color:#000;font-size:17px;font-weight:600}.duplicate-warning{background:#fff3cd;border:1px solid #ffeaa7;color:#856404;padding:15px;border-radius:8px;margin:20px;margin-top:0}.meta-debug{background:#f9f9fb;border:1px solid #e5e5ea;padding:15px;border-radius:8px;font-family:"SF Mono",Monaco,monospace;font-size:12px;max-height:400px;overflow:auto;color:#000}.view-details-btn{background:#007aff;color:#fff;border:none;padding:6px 16px;border-radius:8px;cursor:pointer;font-size:13px;font-weight:500;transition:all 0.2s}.view-details-btn:hover{background:#0051d5;transform:scale(0.98)}.bkash-debugger-controls{display:flex;justify-content:space-between;align-items:center;margin-bottom:20px;background:#fff;padding:16px;border-radius:12px;box-shadow:0 2px 10px rgba(0,0,0,0.08)}.bkash-debugger-search input[type="text"]{padding:10px 16px;border:1px solid #e5e5ea;border-radius:8px;font-size:14px;width:400px;background:#f9f9fb;transition:all 0.2s}.bkash-debugger-search input[type="text"]:focus{outline:none;border-color:#007aff;background:#fff}.bkash-debugger-search input[type="submit"],.bkash-debugger-search .button{background:#007aff;color:#fff;border:none;padding:10px 20px;border-radius:8px;font-size:14px;font-weight:500;cursor:pointer;margin-left:8px;transition:all 0.2s}.bkash-debugger-search input[type="submit"]:hover,.bkash-debugger-search .button:hover{background:#0051d5}.bkash-debugger-pagination{display:flex;align-items:center;gap:8px}.bkash-debugger-pagination a{display:inline-block;padding:8px 12px;background:#f9f9fb;border:1px solid #e5e5ea;text-decoration:none;border-radius:8px;font-size:13px;color:#007aff;transition:all 0.2s}.bkash-debugger-pagination a:hover{background:#e5e5ea}.bkash-debugger-pagination a.current{background:#007aff;color:#fff;border-color:#007aff}.bkash-debugger-pagination span{padding:0 5px;color:#8e8e93}.pagination-info{margin-left:15px;color:#8e8e93;font-size:13px}');
    }
    
    /**
     * Render debugger page
     */
    public function render_debugger_page() {
        // Check if WooCommerce is active
        if (!class_exists('WooCommerce')) {
            echo '<div class="wrap"><h1>Transaction Details</h1>';
            echo '<div class="notice notice-error"><p>WooCommerce is required for this plugin to work.</p></div>';
            echo '</div>';
            return;
        }
        
        // Get pagination parameters
        $per_page = 20;
        $paged = isset($_GET['paged']) ? max(1, intval($_GET['paged'])) : 1;
        $search = isset($_GET['s']) ? sanitize_text_field($_GET['s']) : '';
        
        // Get orders and SMS data
        $orders_data = $this->get_orders_with_pagination($per_page, $paged, $search);
        $sms_logs = $this->get_sms_logs();
        
        echo '<div class="wrap">';
        echo '<h1>Transaction Details</h1>';
        
        // Search form and pagination in same line
        $this->render_controls($search, $orders_data['total'], $per_page, $paged);
        
        // Orders table
        echo '<div class="table-container">';
        $this->render_orders_table($orders_data['orders'], $sms_logs);
        echo '</div>';
        
        echo '</div>';
    }
    
    /**
     * Get orders with pagination
     */
    private function get_orders_with_pagination($per_page, $paged, $search = '') {
        // If searching, handle differently
        if (!empty($search)) {
            return $this->search_orders($search, $per_page, $paged);
        }
        
        // For regular pagination, get all bKash orders
        $args = array(
            'limit' => -1,
            'orderby' => 'date',
            'order' => 'DESC',
            'status' => array('wc-pending', 'wc-processing', 'wc-on-hold', 'wc-completed', 'wc-cancelled', 'wc-refunded', 'wc-failed'),
            'payment_method' => 'pay_bKash'
        );
        
        $all_orders = wc_get_orders($args);
        $total = count($all_orders);
        
        // Slice for pagination
        $offset = ($paged - 1) * $per_page;
        $paged_orders = array_slice($all_orders, $offset, $per_page);
        
        return array(
            'orders' => $paged_orders,
            'total' => $total
        );
    }
    
    /**
     * Search orders by ID, reference number, customer number, or from number
     */
    private function search_orders($search, $per_page, $paged) {
        $found_orders = array();
        $search = trim($search);
        
        // First, try to find by order ID
        if (is_numeric($search)) {
            $order = wc_get_order($search);
            if ($order && $order->get_payment_method() === 'pay_bKash') {
                $found_orders[] = $order;
            }
        }
        
        // Search by reference number
        global $wpdb;
        $order_ids = $wpdb->get_col($wpdb->prepare(
            "SELECT post_id FROM {$wpdb->postmeta} 
            WHERE meta_key = '_bkash_ref_number' 
            AND meta_value LIKE %s",
            '%' . $wpdb->esc_like($search) . '%'
        ));
        
        foreach ($order_ids as $order_id) {
            $order = wc_get_order($order_id);
            if ($order && $order->get_payment_method() === 'pay_bKash' && !in_array($order, $found_orders)) {
                $found_orders[] = $order;
            }
        }
        
        // Search by customer bKash number
        $customer_order_ids = $wpdb->get_col($wpdb->prepare(
            "SELECT post_id FROM {$wpdb->postmeta} 
            WHERE meta_key = '_bKash_number' 
            AND meta_value LIKE %s",
            '%' . $wpdb->esc_like($search) . '%'
        ));
        
        foreach ($customer_order_ids as $order_id) {
            $order = wc_get_order($order_id);
            if ($order && $order->get_payment_method() === 'pay_bKash' && !in_array($order, $found_orders)) {
                $found_orders[] = $order;
            }
        }
        
        // Search by SMS sender number (From field)
        $sms_table = $wpdb->prefix . 'bkash_payments';
        if ($wpdb->get_var("SHOW TABLES LIKE '$sms_table'") === $sms_table) {
            // Get all SMS records with matching sender
            $sms_results = $wpdb->get_results($wpdb->prepare(
                "SELECT DISTINCT reference FROM $sms_table 
                WHERE sender LIKE %s",
                '%' . $wpdb->esc_like($search) . '%'
            ));
            
            // Find orders with these references
            foreach ($sms_results as $sms) {
                if (!empty($sms->reference)) {
                    $ref_order_ids = $wpdb->get_col($wpdb->prepare(
                        "SELECT post_id FROM {$wpdb->postmeta} 
                        WHERE meta_key = '_bkash_ref_number' 
                        AND meta_value = %s",
                        $sms->reference
                    ));
                    
                    foreach ($ref_order_ids as $order_id) {
                        $order = wc_get_order($order_id);
                        if ($order && $order->get_payment_method() === 'pay_bKash' && !in_array($order, $found_orders)) {
                            $found_orders[] = $order;
                        }
                    }
                }
            }
        }
        
        // Remove duplicates by order ID
        $unique_orders = array();
        $seen_ids = array();
        foreach ($found_orders as $order) {
            $order_id = $order->get_id();
            if (!in_array($order_id, $seen_ids)) {
                $unique_orders[] = $order;
                $seen_ids[] = $order_id;
            }
        }
        
        // Sort by date
        usort($unique_orders, function($a, $b) {
            return $b->get_date_created()->getTimestamp() - $a->get_date_created()->getTimestamp();
        });
        
        $total = count($unique_orders);
        
        // Paginate results
        $offset = ($paged - 1) * $per_page;
        $paged_orders = array_slice($unique_orders, $offset, $per_page);
        
        return array(
            'orders' => $paged_orders,
            'total' => $total
        );
    }
    
    /**
     * Get SMS logs from database
     */
    private function get_sms_logs() {
        global $wpdb;
        
        $table_name = $wpdb->prefix . 'bkash_payments';
        
        // Check if table exists
        if ($wpdb->get_var("SHOW TABLES LIKE '$table_name'") !== $table_name) {
            return array();
        }
        
        $results = $wpdb->get_results("SELECT * FROM $table_name ORDER BY id DESC");
        
        // Index by normalized reference for quick lookup
        $indexed_sms = array();
        foreach ($results as $sms) {
            $normalized_ref = trim($sms->reference);
            if (!empty($normalized_ref)) {
                if (!isset($indexed_sms[$normalized_ref])) {
                    $indexed_sms[$normalized_ref] = array();
                }
                $indexed_sms[$normalized_ref][] = $sms;
            }
        }
        
        return $indexed_sms;
    }
    
    /**
     * Render search form and pagination controls
     */
    private function render_controls($search, $total_orders, $per_page, $current_page) {
        echo '<div class="bkash-debugger-controls">';
        
        // Search form
        echo '<div class="bkash-debugger-search">';
        echo '<form method="get" style="display: inline-block;">';
        echo '<input type="hidden" name="page" value="bkash-order-debugger">';
        echo '<input type="text" name="s" value="' . esc_attr($search) . '" placeholder="Search by Order ID, Reference, Customer Number, or From Number">';
        echo '<input type="submit" value="Search">';
        if (!empty($search)) {
            echo '<a href="' . esc_url(admin_url('admin.php?page=bkash-order-debugger')) . '" class="button">Clear</a>';
        }
        echo '</form>';
        echo '</div>';
        
        // Pagination
        $total_pages = ceil($total_orders / $per_page);
        
        if ($total_pages > 1) {
            echo '<div class="bkash-debugger-pagination">';
            
            $base_url = admin_url('admin.php?page=bkash-order-debugger');
            if (!empty($search)) {
                $base_url .= '&s=' . urlencode($search);
            }
            
            // Previous page
            if ($current_page > 1) {
                echo '<a href="' . esc_url($base_url . '&paged=' . ($current_page - 1)) . '">&laquo;</a>';
            }
            
            // Page numbers
            $start = max(1, $current_page - 2);
            $end = min($total_pages, $current_page + 2);
            
            if ($start > 1) {
                echo '<a href="' . esc_url($base_url . '&paged=1') . '">1</a>';
                if ($start > 2) {
                    echo '<span>...</span>';
                }
            }
            
            for ($i = $start; $i <= $end; $i++) {
                $class = ($i === $current_page) ? 'current' : '';
                echo '<a href="' . esc_url($base_url . '&paged=' . $i) . '" class="' . $class . '">' . $i . '</a>';
            }
            
            if ($end < $total_pages) {
                if ($end < $total_pages - 1) {
                    echo '<span>...</span>';
                }
                echo '<a href="' . esc_url($base_url . '&paged=' . $total_pages) . '">' . $total_pages . '</a>';
            }
            
            // Next page
            if ($current_page < $total_pages) {
                echo '<a href="' . esc_url($base_url . '&paged=' . ($current_page + 1)) . '">&raquo;</a>';
            }
            
            // Show results info
            $start_result = (($current_page - 1) * $per_page) + 1;
            $end_result = min($current_page * $per_page, $total_orders);
            echo '<span class="pagination-info">';
            echo 'Showing ' . $start_result . '-' . $end_result . ' of ' . $total_orders;
            echo '</span>';
            
            echo '</div>';
        }
        
        echo '</div>';
    }
    
    /**
     * Render orders table
     */
    private function render_orders_table($orders, $sms_logs) {
        echo '<table class="bkash-debugger-table">';
        echo '<thead>';
        echo '<tr>';
        echo '<th>Order ID</th>';
        echo '<th>Billing Name</th>';
        echo '<th>Status</th>';
        echo '<th>Order Date</th>';
        echo '<th>Order Details</th>';
        echo '<th>SMS Details</th>';
        echo '<th>Match Status</th>';
        echo '<th>Actions</th>';
        echo '</tr>';
        echo '</thead>';
        echo '<tbody>';
        
        if (empty($orders)) {
            echo '<tr><td colspan="8" style="text-align: center;">No bKash orders found.</td></tr>';
        } else {
            foreach ($orders as $order) {
                $this->render_order_row($order, $sms_logs);
            }
        }
        
        echo '</tbody>';
        echo '</table>';
        
        // Render modals for all orders
        foreach ($orders as $order) {
            $this->render_order_modal($order, $sms_logs);
        }
    }
    
    /**
     * Render single order row
     */
    private function render_order_row($order, $sms_logs) {
        $order_id = $order->get_id();
        $order_total = floatval($order->get_total());
        $ref_number = get_post_meta($order_id, '_bkash_ref_number', true);
        $customer_bkash = get_post_meta($order_id, '_bKash_number', true);
        
        // Get matching SMS data with validation
        $matching_result = $this->get_matching_sms_with_validation($ref_number, $customer_bkash, $order_total, $sms_logs);
        
        echo '<tr>';
        
        // Order ID
        echo '<td>';
        echo '<a href="' . esc_url(admin_url('post.php?post=' . $order_id . '&action=edit')) . '" target="_blank" style="color: #007aff; text-decoration: none;">';
        echo '#' . esc_html($order_id);
        echo '</a>';
        echo '</td>';
        
        // Billing Name
        echo '<td>' . esc_html($order->get_billing_first_name() . ' ' . $order->get_billing_last_name()) . '</td>';
        
        // Status
        echo '<td>' . esc_html(ucfirst($order->get_status())) . '</td>';
        
        // Order Date
        echo '<td>' . esc_html($order->get_date_created()->date('Y-m-d H:i:s')) . '</td>';
        
        // Order Details Column
        echo '<td>';
        echo '<div class="details-container">';
        
        // Total
        echo '<div class="detail-item">';
        echo '<span class="detail-content ' . ($matching_result['amount_match'] ? 'match-success' : (!empty($matching_result['sms_data']) ? 'match-fail' : '')) . '">';
        echo '<span class="detail-label">Total:</span> ';
        echo '<span class="detail-value">' . get_woocommerce_currency_symbol() . number_format($order_total, 2) . '</span>';
        echo '</span>';
        echo '</div>';
        
        // Customer bKash
        echo '<div class="detail-item">';
        echo '<span class="detail-content ' . ($matching_result['sender_match'] ? 'match-success' : (!empty($matching_result['sms_data']) && !empty($customer_bkash) ? 'match-fail' : '')) . '">';
        echo '<span class="detail-label">Customer:</span> ';
        echo '<span class="detail-value">' . (!empty($customer_bkash) ? esc_html($customer_bkash) : 'No number') . '</span>';
        echo '</span>';
        echo '</div>';
        
        // Reference Number
        echo '<div class="detail-item">';
        echo '<span class="detail-content ' . ($matching_result['ref_match'] ? 'match-success' : (!empty($matching_result['sms_data']) && !empty($ref_number) ? 'match-fail' : '')) . '">';
        echo '<span class="detail-label">Reference:</span> ';
        echo '<span class="detail-value">' . (!empty($ref_number) ? esc_html($ref_number) : 'No reference') . '</span>';
        echo '</span>';
        echo '</div>';
        
        echo '</div>';
        echo '</td>';
        
        // SMS Details Column
        echo '<td>';
        if (!empty($matching_result['sms_data'])) {
            echo '<div class="details-container">';
            
            // Amount
            echo '<div class="detail-item">';
            echo '<span class="detail-content ' . ($matching_result['amount_match'] ? 'match-success' : 'match-fail') . '">';
            echo '<span class="detail-label">Amount:</span> ';
            echo '<span class="detail-value">৳' . number_format($matching_result['sms_data']['amount'], 2) . '</span>';
            echo '</span>';
            echo '</div>';
            
            // From
            echo '<div class="detail-item">';
            echo '<span class="detail-content ' . ($matching_result['sender_match'] ? 'match-success' : 'match-fail') . '">';
            echo '<span class="detail-label">From:</span> ';
            echo '<span class="detail-value">' . esc_html($matching_result['sms_data']['sender']) . '</span>';
            echo '</span>';
            echo '</div>';
            
            // Ref
            echo '<div class="detail-item">';
            echo '<span class="detail-content ' . ($matching_result['ref_match'] ? 'match-success' : 'match-fail') . '">';
            echo '<span class="detail-label">Ref:</span> ';
            echo '<span class="detail-value">' . esc_html($matching_result['sms_data']['reference']) . '</span>';
            echo '</span>';
            echo '</div>';
            
            echo '</div>';
        } else {
            echo '<div class="details-container">';
            echo '<div class="detail-item">';
            echo '<span class="detail-content no-data">No SMS found</span>';
            echo '</div>';
            echo '</div>';
        }
        echo '</td>';
        
        // Match Status
        echo '<td>';
        if ($matching_result['all_match']) {
            echo '<span class="match-status all-match">✓ All Matched</span>';
        } elseif (!empty($matching_result['sms_data'])) {
            $matches = [];
            if ($matching_result['ref_match']) $matches[] = 'Ref';
            if ($matching_result['sender_match']) $matches[] = 'Sender';
            if ($matching_result['amount_match']) $matches[] = 'Amount';
            
            if (!empty($matches)) {
                echo '<span class="match-status partial-match">⚠ Partial: ' . implode(', ', $matches) . '</span>';
            } else {
                echo '<span class="match-status no-match">✗ No Match</span>';
            }
        } else {
            echo '<span class="match-status no-sms">No SMS</span>';
        }
        echo '</td>';
        
        // Actions
        echo '<td>';
        echo '<button class="view-details-btn" data-order-id="' . esc_attr($order_id) . '">View Details</button>';
        echo '</td>';
        
        echo '</tr>';
    }
    
    /**
     * Render order modal
     */
    private function render_order_modal($order, $sms_logs) {
        $order_id = $order->get_id();
        $ref_number = get_post_meta($order_id, '_bkash_ref_number', true);
        $all_meta = get_post_meta($order_id);
        
        // Get duplicate payment info
        $duplicates = $this->get_duplicate_payments($ref_number, $sms_logs);
        
        // Separate bKash and other meta
        $bkash_meta = array();
        $other_meta = array();
        
        foreach ($all_meta as $key => $value) {
            if (strpos(strtolower($key), 'bkash') !== false || 
                in_array($key, array('_payment_method', '_order_total', '_billing_phone'))) {
                $bkash_meta[$key] = $value;
            } else {
                $other_meta[$key] = $value;
            }
        }
        
        echo '<div id="modal-' . esc_attr($order_id) . '" class="bkash-modal">';
        echo '<div class="bkash-modal-content">';
        echo '<div class="modal-header">';
        echo '<span class="close-modal">&times;</span>';
        echo '<h2>Order #' . esc_html($order_id) . ' - Debug Information</h2>';
        echo '</div>';
        
        // Duplicate warnings
        if (!empty($duplicates)) {
            echo '<div class="duplicate-warning">';
            echo '<strong>⚠️ DUPLICATE PAYMENTS DETECTED:</strong><br>';
            
            if (isset($duplicates['sms_duplicates'])) {
                echo '<br><strong>Multiple SMS with same reference (' . count($duplicates['sms_duplicates']) . ' found):</strong><br>';
                foreach ($duplicates['sms_duplicates'] as $sms) {
                    echo '- Amount: ৳' . esc_html($sms->amount) . ', From: ' . esc_html($sms->sender) . ', Time: ' . esc_html($sms->timestamp) . '<br>';
                }
            }
            
            if (isset($duplicates['order_duplicates'])) {
                echo '<br><strong>Multiple orders with same reference:</strong><br>';
                echo 'Order IDs: ' . implode(', ', array_map(function($id) { return '#' . $id; }, $duplicates['order_duplicates'])) . '<br>';
            }
            echo '</div>';
        }
        
        // Order Information
        echo '<div class="modal-section">';
        echo '<h3>Order Information</h3>';
        echo '<p><strong>Order Date:</strong> ' . esc_html($order->get_date_created()->date('Y-m-d H:i:s')) . '</p>';
        $completed_date = $order->get_date_completed();
        echo '<p><strong>Completed Date:</strong> ' . ($completed_date ? esc_html($completed_date->date('Y-m-d H:i:s')) : '<em>Not completed</em>') . '</p>';
        echo '<p><strong>Status:</strong> ' . esc_html(ucfirst($order->get_status())) . '</p>';
        echo '<p><strong>Total:</strong> ' . esc_html(get_woocommerce_currency_symbol() . ' ' . number_format($order->get_total(), 2)) . '</p>';
        echo '</div>';
        
        // bKash Meta
        echo '<div class="modal-section">';
        echo '<h3>bKash Related Meta</h3>';
        echo '<pre class="meta-debug">';
        echo esc_html(print_r($bkash_meta, true));
        echo '</pre>';
        echo '</div>';
        
        // Other Meta
        if (!empty($other_meta)) {
            echo '<div class="modal-section">';
            echo '<h3>Other Meta (first 20 fields)</h3>';
            echo '<pre class="meta-debug">';
            $limited_meta = array_slice($other_meta, 0, 20, true);
            echo esc_html(print_r($limited_meta, true));
            if (count($other_meta) > 20) {
                echo "\n... (" . (count($other_meta) - 20) . " more meta fields)";
            }
            echo '</pre>';
            echo '</div>';
        }
        
        echo '</div>';
        echo '</div>';
    }
    
    /**
     * Get matching SMS data with full validation
     */
    private function get_matching_sms_with_validation($ref_number, $customer_bkash, $order_total, $sms_logs) {
        if (empty($ref_number)) {
            return array(
                'sms_data' => null,
                'ref_match' => false,
                'sender_match' => false,
                'amount_match' => false,
                'all_match' => false
            );
        }
        
        $normalized_ref = trim($ref_number);
        
        if (!isset($sms_logs[$normalized_ref]) || empty($sms_logs[$normalized_ref])) {
            return array(
                'sms_data' => null,
                'ref_match' => false,
                'sender_match' => false,
                'amount_match' => false,
                'all_match' => false
            );
        }
        
        // Get first matching SMS
        $sms = $sms_logs[$normalized_ref][0];
        
        // Normalize phone numbers (remove country code)
        $normalized_customer = preg_replace('/^(\+88|88)/', '', trim($customer_bkash));
        $normalized_sender = preg_replace('/^(\+88|88)/', '', trim($sms->sender));
        
        // Check matches
        $ref_match = (trim($sms->reference) === $normalized_ref);
        $sender_match = ($normalized_sender === $normalized_customer);
        $amount_match = (abs(floatval($sms->amount) - floatval($order_total)) < 0.01);
        
        return array(
            'sms_data' => array(
                'reference' => $sms->reference,
                'sender' => $sms->sender,
                'amount' => $sms->amount,
                'trxid' => $sms->trxid,
                'timestamp' => $sms->timestamp
            ),
            'ref_match' => $ref_match,
            'sender_match' => $sender_match,
            'amount_match' => $amount_match,
            'all_match' => ($ref_match && $sender_match && $amount_match)
        );
    }

    /**
     * Get duplicate payment information
     */
    private function get_duplicate_payments($ref_number, $sms_logs) {
        $duplicates = array();
        
        if (empty($ref_number)) {
            return $duplicates;
        }
        
        // Check SMS logs for multiple payments with same reference
        if (isset($sms_logs[$ref_number]) && count($sms_logs[$ref_number]) > 1) {
            $duplicates['sms_duplicates'] = $sms_logs[$ref_number];
        }
        
        // Check orders for multiple orders with same reference
        global $wpdb;
        $order_ids = $wpdb->get_col($wpdb->prepare(
            "SELECT post_id FROM {$wpdb->postmeta} 
            WHERE meta_key = '_bkash_ref_number' 
            AND meta_value = %s",
            $ref_number
        ));
        
        if (count($order_ids) > 1) {
            $duplicates['order_duplicates'] = $order_ids;
        }
        
        return $duplicates;
    }
}

// Create instance
$GLOBALS['bkash_order_debugger'] = new BkashOrderDebugger();

// Function to render the debugger page
function bkash_order_debugger_page() {
    global $bkash_order_debugger;
    $bkash_order_debugger->render_debugger_page();
}