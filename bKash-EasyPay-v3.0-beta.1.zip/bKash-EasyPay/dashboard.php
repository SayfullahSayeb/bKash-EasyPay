<?php

/**
 * Main Dashboard Page
 */
function bkash_easypay_dashboard_page() {
    // Get dashboard data
    $dashboard_data = get_bkash_dashboard_data();
    ?>
    <div class="wrap bkash-dashboard">
        <h1 class="dashboard-title">
            <img src="<?php echo plugins_url('images/BKash-Icon-Logo.wine.svg', __FILE__); ?>" alt="bKash" class="dashboard-logo">
            bKash EasyPay
        </h1>
        
        <!-- WooCommerce Overview Stats -->
        <div class="stats-container">
            <div class="stat-card">
                <div class="stat-header">
                    <span class="stat-icon">🛍️</span>
                    <span class="stat-label">Total Orders</span>
                </div>
                <div class="stat-value"><?php echo number_format($dashboard_data['wc_total_orders']); ?></div>
                <div class="stat-subtitle">All Payment Methods</div>
            </div>

            <div class="stat-card">
                <div class="stat-header">
                    <span class="stat-icon">📦</span>
                    <span class="stat-label">Items Sold</span>
                </div>
                <div class="stat-value"><?php echo number_format($dashboard_data['wc_items_sold']); ?></div>
                <div class="stat-subtitle">Total Products</div>
            </div>
            
            <div class="stat-card">
                <div class="stat-header">
                    <span class="stat-icon">✅</span>
                    <span class="stat-label">Completed Orders</span>
                </div>
                <div class="stat-value"><?php echo number_format($dashboard_data['wc_completed_orders']); ?></div>
                <div class="stat-subtitle"><?php echo round(($dashboard_data['wc_completed_orders'] / max($dashboard_data['wc_total_orders'], 1)) * 100, 1); ?>% Success Rate</div>
            </div>
            
            <div class="stat-card">
                <div class="stat-header">
                    <span class="stat-icon">💵</span>
                    <span class="stat-label">Total Sales</span>
                </div>
                <div class="stat-value"><?php echo wc_price($dashboard_data['wc_total_sales']); ?></div>
                <div class="stat-subtitle">Gross Revenue</div>
            </div>
            
            <div class="stat-card">
                <div class="stat-header">
                    <span class="stat-icon">💰</span>
                    <span class="stat-label">Net Sales</span>
                </div>
                <div class="stat-value"><?php echo wc_price($dashboard_data['wc_net_sales']); ?></div>
                <div class="stat-subtitle">After Refunds & Discounts</div>
            </div>
            
            <div class="stat-card">
                <div class="stat-header">
                    <span class="stat-icon">🎟️</span>
                    <span class="stat-label">Coupons Used</span>
                </div>
                <div class="stat-value"><?php echo number_format($dashboard_data['wc_coupons_count']); ?></div>
                <div class="stat-subtitle"><?php echo wc_price($dashboard_data['wc_coupons_amount']); ?> Discount</div>
            </div>
            
        </div>

        <!-- bKash Specific Stats -->
        <div class="stats-container">
            <div class="stat-card highlight">
                <div class="stat-header">
                    <span class="stat-icon">💳</span>
                    <span class="stat-label">bKash Orders</span>
                </div>
                <div class="stat-value"><?php echo number_format($dashboard_data['total_orders']); ?></div>
                <div class="stat-subtitle"><?php echo round(($dashboard_data['total_orders'] / max($dashboard_data['wc_total_orders'], 1)) * 100, 1); ?>% of Total Orders</div>
            </div>
            
            <div class="stat-card highlight">
                <div class="stat-header">
                    <span class="stat-icon">💸</span>
                    <span class="stat-label">bKash Revenue</span>
                </div>
                <div class="stat-value"><?php echo wc_price($dashboard_data['total_sales']); ?></div>
                <div class="stat-subtitle"><?php echo round(($dashboard_data['total_sales'] / max($dashboard_data['wc_total_sales'], 1)) * 100, 1); ?>% of Total Revenue</div>
            </div>

            <div class="stat-card">
                <div class="stat-header">
                    <span class="stat-icon">📱</span>
                    <span class="stat-label">SMS Received</span>
                </div>
                <div class="stat-value"><?php echo number_format($dashboard_data['total_sms']); ?></div>
                <div class="stat-subtitle">Payment Confirmations</div>
            </div>
            
            <div class="stat-card">
                <div class="stat-header">
                    <span class="stat-icon">⏳</span>
                    <span class="stat-label">Pending</span>
                </div>
                <div class="stat-value"><?php echo $dashboard_data['pending_orders']; ?></div>
                <div class="stat-subtitle">Awaiting Payment</div>
            </div>
            
            <div class="stat-card">
                <div class="stat-header">
                    <span class="stat-icon">↩️</span>
                    <span class="stat-label">Refunds</span>
                </div>
                <div class="stat-value"><?php echo number_format($dashboard_data['wc_refunds_count']); ?></div>
                <div class="stat-subtitle"><?php echo wc_price($dashboard_data['wc_refunds_amount']); ?> Refunded</div>
            </div>

        </div>

        <div class="main-grid">
            <!-- Recent Orders -->
            <div class="ios-card">
                <div class="card-header">
                    <h2>Recent bKash Orders</h2>
                    <a href="<?php echo admin_url('admin.php?page=pay_bKash_transactions'); ?>" class="ios-link">View All</a>
                </div>
                <?php if (!empty($dashboard_data['recent_orders'])): ?>
                    <div class="ios-list">
                        <?php foreach ($dashboard_data['recent_orders'] as $order): ?>
                            <a href="<?php echo admin_url('post.php?post=' . $order->get_id() . '&action=edit'); ?>" class="list-item clickable">
                                <div class="list-content">
                                    <div class="list-title">Order #<?php echo $order->get_id(); ?></div>
                                    <div class="list-subtitle"><?php echo esc_html($order->get_billing_first_name() . ' ' . $order->get_billing_last_name()); ?> • <?php echo $order->get_date_created()->date('M d, Y'); ?></div>
                                </div>
                                <div class="list-right">
                                    <div class="list-amount"><?php echo wc_price($order->get_total()); ?></div>
                                    <div class="status-pill status-<?php echo $order->get_status(); ?>"><?php echo ucfirst($order->get_status()); ?></div>
                                </div>
                            </a>
                        <?php endforeach; ?>
                    </div>
                <?php else: ?>
                    <div class="empty-state">No recent orders found</div>
                <?php endif; ?>
            </div>

            <div class="side-column">
                <!-- Quick Actions -->
                <div class="ios-card">
                    <div class="card-header">
                        <h2>Quick Actions</h2>
                    </div>
                    <div class="ios-list">
                        <a href="<?php echo admin_url('admin.php?page=bkash-payment-settings'); ?>" class="list-item clickable">
                            <span class="list-icon">⚙️</span>
                            <span class="list-content">Plugin Settings</span>
                            <span class="list-chevron">›</span>
                        </a>
                        <a href="<?php echo admin_url('admin.php?page=pay_bKash_transactions'); ?>" class="list-item clickable">
                            <span class="list-icon">📋</span>
                            <span class="list-content">Order History</span>
                            <span class="list-chevron">›</span>
                        </a>
                        <a href="<?php echo admin_url('admin.php?page=bkash-order-debugger'); ?>" class="list-item clickable">
                            <span class="list-icon">🗒️</span>
                            <span class="list-content">bKash Transaction Details</span>
                            <span class="list-chevron">›</span>
                        </a>
                        <a href="<?php echo admin_url('admin.php?page=bkash-sms-logs'); ?>" class="list-item clickable">
                            <span class="list-icon">✉️</span>
                            <span class="list-content">SMS Logs</span>
                            <span class="list-chevron">›</span>
                        </a>
                        <a href="<?php echo admin_url('admin.php?page=bkash-sms-api'); ?>" class="list-item clickable">
                            <span class="list-icon">🔗</span>
                            <span class="list-content">SMS API Settings</span>
                            <span class="list-chevron">›</span>
                        </a>
                    </div>
                </div>

                <!-- System Status -->
                <div class="ios-card">
                    <div class="card-header">
                        <h2>System Status</h2>
                    </div>
                    <div class="ios-list">
                        <div class="list-item">
                            <span class="status-dot <?php echo class_exists('WooCommerce') ? 'active' : 'inactive'; ?>"></span>
                            <span class="list-content">WooCommerce</span>
                            <span class="list-value"><?php echo class_exists('WooCommerce') ? 'Active' : 'Inactive'; ?></span>
                        </div>
                        <div class="list-item">
                            <span class="status-dot <?php echo $dashboard_data['sms_table_exists'] ? 'active' : 'warning'; ?>"></span>
                            <span class="list-content">SMS Database</span>
                            <span class="list-value"><?php echo $dashboard_data['sms_table_exists'] ? 'Connected' : 'Not Setup'; ?></span>
                        </div>
                        <div class="list-item">
                            <span class="status-dot <?php echo !empty(get_option('bkash_sms_api_key')) ? 'active' : 'warning'; ?>"></span>
                            <span class="list-content">SMS API</span>
                            <span class="list-value"><?php echo !empty(get_option('bkash_sms_api_key')) ? 'Configured' : 'Not Setup'; ?></span>
                        </div>
                        <div class="list-item">
                            <span class="status-dot active"></span>
                            <span class="list-content">Plugin Version</span>
                            <span class="list-value">v2.0.0</span>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <style>.bkash-dashboard{max-width:100%;margin:20px 20px;font-family:-apple-system,BlinkMacSystemFont,"Segoe UI",Roboto,Helvetica,Arial,sans-serif}.dashboard-title{display:flex;align-items:center;font-size:34px;font-weight:700;margin-bottom:30px;color:#000}.dashboard-logo{width:40px;height:40px;margin-right:12px}.stats-container{display:grid;grid-template-columns:repeat(auto-fit,minmax(200px,1fr));gap:16px;margin-bottom:20px}.stat-card{background:#fff;border-radius:16px;padding:20px;box-shadow:0 2px 8px rgba(0,0,0,0.04);transition:all 0.2s ease;border:1px solid #f2f2f7}.stat-card:hover{transform:translateY(-2px);box-shadow:0 4px 16px rgba(0,0,0,0.08)}.stat-card.highlight{background:linear-gradient(135deg,#e91e63 0%,#d81b60 100%);color:#fff}.stat-card.highlight .stat-label,.stat-card.highlight .stat-subtitle{color:rgba(255,255,255,0.9)}.stat-card.highlight .stat-value{color:#fff}.stat-header{display:flex;align-items:center;margin-bottom:12px}.stat-icon{font-size:24px;margin-right:8px}.stat-label{font-size:13px;color:#8e8e93;font-weight:600;text-transform:uppercase;letter-spacing:0.5px}.stat-value{font-size:28px;font-weight:700;color:#000;margin-bottom:4px;line-height:1}.stat-subtitle{font-size:13px;color:#8e8e93}.main-grid{display:grid;grid-template-columns:1.5fr 1fr;gap:20px;margin-bottom:20px}.side-column{display:flex;flex-direction:column;gap:20px}.ios-card{background:#fff;border-radius:16px;box-shadow:0 2px 8px rgba(0,0,0,0.04);overflow:hidden;border:1px solid #f2f2f7}.card-header{padding:20px;border-bottom:1px solid #f2f2f7;display:flex;justify-content:space-between;align-items:center}.card-header h2{margin:0;font-size:20px;font-weight:600;color:#000}.ios-link{color:#007aff;text-decoration:none;font-size:15px;font-weight:500}.ios-link:hover{color:#0051d5}.ios-list{background:#fff}.list-item{display:flex;align-items:center;padding:16px 20px;border-bottom:1px solid #f2f2f7;position:relative;color:#000;text-decoration:none}.list-item:last-child{border-bottom:none}.list-item.clickable{cursor:pointer;transition:background 0.2s ease}.list-item.clickable:hover{background:#f2f2f7}.list-icon{font-size:20px;margin-right:12px}.list-content{flex:1;font-size:16px;color:#000}.list-title{font-size:16px;font-weight:500;color:#000;margin-bottom:2px}.list-subtitle{font-size:13px;color:#8e8e93}.list-right{text-align:right}.list-amount{font-size:16px;font-weight:600;color:#000;margin-bottom:4px}.list-value{font-size:15px;color:#8e8e93}.list-chevron{font-size:20px;color:#c7c7cc;margin-left:8px}.status-pill{display:inline-block;padding:4px 10px;border-radius:12px;font-size:11px;font-weight:600;text-transform:uppercase}.status-completed{background:#d1f2d1;color:#1d8f1d}.status-processing{background:#cce5ff;color:#004085}.status-pending{background:#fff3cd;color:#856404}.status-on-hold{background:#f8d7da;color:#721c24}.status-cancelled{background:#e2e3e5;color:#383d41}.status-refunded{background:#e2e3e5;color:#383d41}.status-dot{width:8px;height:8px;border-radius:50%;display:inline-block;margin-right:12px}.status-dot.active{background:#34c759}.status-dot.warning{background:#ff9500}.status-dot.inactive{background:#ff3b30}.empty-state{padding:40px;text-align:center;color:#8e8e93;font-size:15px}@media(max-width:1200px){.main-grid{grid-template-columns:1fr}.side-column{flex-direction:row}.side-column .ios-card{flex:1}}@media(max-width:768px){.stats-container{grid-template-columns:1fr 1fr}.stat-card{padding:16px}.stat-value{font-size:24px}.dashboard-title{font-size:28px}.side-column{flex-direction:column}}@media(max-width:480px){.stats-container{grid-template-columns:1fr}}</style>
    <?php
}

/**
 * Get Dashboard Data
 */
function get_bkash_dashboard_data() {
    global $wpdb;
    
    // Get all bKash orders
    $bkash_orders = wc_get_orders(array(
        'limit' => -1,
        'status' => array('wc-pending', 'wc-processing', 'wc-on-hold', 'wc-completed', 'wc-cancelled', 'wc-refunded', 'wc-failed'),
        'payment_method' => 'pay_bKash'
    ));
    
    // Calculate bKash totals
    $total_orders = count($bkash_orders);
    $total_sales = 0;
    $order_statuses = array();
    $pending_orders = 0;
    
    foreach ($bkash_orders as $order) {
        $total_sales += $order->get_total();
        $status = $order->get_status();
        
        if (!isset($order_statuses[$status])) {
            $order_statuses[$status] = 0;
        }
        $order_statuses[$status]++;
        
        if (in_array($status, array('pending', 'on-hold'))) {
            $pending_orders++;
        }
    }
    
    // Get WooCommerce totals (all payment methods)
    $wc_orders = wc_get_orders(array(
        'limit' => -1,
        'status' => array('wc-pending', 'wc-processing', 'wc-on-hold', 'wc-completed', 'wc-cancelled', 'wc-refunded', 'wc-failed'),
        'type' => 'shop_order'
    ));
    
    $wc_total_orders = count($wc_orders);
    $wc_total_sales = 0;
    $wc_net_sales = 0;
    $wc_items_sold = 0;
    $wc_coupons_amount = 0;
    $wc_coupons_count = 0;
    $wc_refunds_amount = 0;
    $wc_refunds_count = 0;
    $wc_completed_orders = 0;
    
    // Track unique orders that have been refunded
    $refunded_order_ids = array();
    
    foreach ($wc_orders as $order) {
        // Skip if this is not an order
        if (!is_a($order, 'WC_Order')) {
            continue;
        }
        
        $wc_total_sales += $order->get_total();
        
        // Count completed orders
        if ($order->get_status() === 'completed') {
            $wc_completed_orders++;
        }
        
        // Check for refunds - count orders with refunded status OR orders that have refunds
        $has_refunds = false;
        $order_refund_amount = 0;
        
        // Check if order has refunded status
        if ($order->get_status() === 'refunded') {
            $has_refunds = true;
            $order_refund_amount = $order->get_total();
        }
        
        // Check for partial refunds
        $total_refunded = $order->get_total_refunded();
        if ($total_refunded > 0) {
            $has_refunds = true;
            $order_refund_amount = max($order_refund_amount, $total_refunded);
        }
        
        // If this order has any refunds and we haven't counted it yet
        if ($has_refunds && !in_array($order->get_id(), $refunded_order_ids)) {
            $wc_refunds_count++;
            $wc_refunds_amount += $order_refund_amount;
            $refunded_order_ids[] = $order->get_id();
        }
        
        // Calculate net sales
        $wc_net_sales += ($order->get_total() - $total_refunded);
        
        // Count items sold
        foreach ($order->get_items() as $item) {
            $wc_items_sold += $item->get_quantity();
        }
        
        // Count coupons
        $coupons = $order->get_coupon_codes();
        if (!empty($coupons)) {
            $wc_coupons_count += count($coupons);
            $wc_coupons_amount += $order->get_discount_total();
        }
    }
    
    // Alternative method: Get refund data directly from database if above doesn't work
    if ($wc_refunds_count == 0) {
        // Get all refund posts
        $refund_posts = get_posts(array(
            'post_type' => 'shop_order_refund',
            'post_status' => 'any',
            'numberposts' => -1,
            'fields' => 'ids'
        ));
        
        if (!empty($refund_posts)) {
            $wc_refunds_count = count($refund_posts);
            
            foreach ($refund_posts as $refund_id) {
                $refund = wc_get_order($refund_id);
                if ($refund) {
                    $wc_refunds_amount += abs($refund->get_total());
                }
            }
        }
    }
    
    // Get recent orders (last 7)
    $recent_orders = wc_get_orders(array(
        'limit' => 7,
        'orderby' => 'date',
        'order' => 'DESC',
        'payment_method' => 'pay_bKash'
    ));
    
    // Get SMS data
    $sms_table = $wpdb->prefix . 'bkash_payments';
    $sms_table_exists = ($wpdb->get_var("SHOW TABLES LIKE '$sms_table'") === $sms_table);
    $total_sms = 0;
    $recent_sms = array();
    
    if ($sms_table_exists) {
        $total_sms = $wpdb->get_var("SELECT COUNT(*) FROM $sms_table");
        $recent_sms = $wpdb->get_results("SELECT * FROM $sms_table ORDER BY id DESC LIMIT 5");
    }
    
    return array(
        // bKash specific
        'total_orders' => $total_orders,
        'total_sales' => $total_sales,
        'pending_orders' => $pending_orders,
        'order_statuses' => $order_statuses,
        'recent_orders' => $recent_orders,
        'total_sms' => $total_sms,
        'recent_sms' => $recent_sms,
        'sms_table_exists' => $sms_table_exists,
        
        // WooCommerce totals
        'wc_total_orders' => $wc_total_orders,
        'wc_completed_orders' => $wc_completed_orders,
        'wc_total_sales' => $wc_total_sales,
        'wc_net_sales' => $wc_net_sales,
        'wc_items_sold' => $wc_items_sold,
        'wc_coupons_count' => $wc_coupons_count,
        'wc_coupons_amount' => $wc_coupons_amount,
        'wc_refunds_count' => $wc_refunds_count,
        'wc_refunds_amount' => $wc_refunds_amount
    );
}