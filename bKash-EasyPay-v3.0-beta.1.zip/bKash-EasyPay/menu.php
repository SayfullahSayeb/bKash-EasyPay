<?php
// Add admin menu and submenus
add_action('admin_menu', function() {
    $icon_svg = plugins_url('images/BKash-Icon-Logo.wine.svg', __FILE__);
    add_menu_page(
        'bKash EasyPay Dashboard',
        'EasyPay',
        'manage_options',
        'bkash_easypay_menu',
        'bkash_easypay_dashboard_page',
        $icon_svg,
        55
    );
    add_submenu_page('bkash_easypay_menu', 'Order History', 'Order History', 'manage_options', 'pay_bKash_transactions', 'pay_bKash_transactions_page');
    add_submenu_page('bkash_easypay_menu', 'Transaction Details', 'Transaction Details', 'manage_options', 'bkash-order-debugger', 'bkash_order_debugger_page');
    add_submenu_page('bkash_easypay_menu', 'SMS Logs', 'SMS Logs', 'manage_options', 'bkash-sms-logs', 'easypay_render_sms_logs');
    add_submenu_page('bkash_easypay_menu', 'SMS API Settings', 'SMS API Settings', 'manage_options', 'bkash-sms-api', 'bkash_sms_api_settings_page');
    add_submenu_page('bkash_easypay_menu', 'Payment Settings', 'Payment Settings', 'manage_options', 'bkash-payment-settings', 'bkash_woocommerce_settings_page');
});

// Add CSS to ensure SVG displays correctly
add_action('admin_head', function() {
    ?>
    <style>
        #adminmenu .toplevel_page_bkash_easypay_menu .wp-menu-image img {
            width: 20px !important;
            height: 20px !important;
        }
    </style>
    <?php
});