<?php

/**
 * Helper Functions - Centralized common operations
 */

    // bKash Charge Functionality
    $bKash_charge = get_option('woocommerce_pay_bKash_settings');
    if ($bKash_charge['bKash_charge'] == 'yes') {
        
        add_action('wp_enqueue_scripts', function() {
            wp_enqueue_script('stb-script', plugins_url('js/scripts.js', __FILE__), ['jquery'], '1.0', true);
        });

        add_action('woocommerce_cart_calculate_fees', function() {
            global $woocommerce;
            
            if (is_admin() && !defined('DOING_AJAX')) return;
            
            $available_gateways = $woocommerce->payment_gateways->get_available_payment_gateways();
            $current_gateway = '';

            if (!empty($available_gateways) && isset($woocommerce->session->chosen_payment_method)) {
                $current_gateway = $available_gateways[$woocommerce->session->chosen_payment_method] ?? '';
            }
            
            if ($current_gateway && $current_gateway->id == 'pay_bKash') {
                $percentage = 0.02;
                $surcharge = ($woocommerce->cart->cart_contents_total + $woocommerce->cart->shipping_total) * $percentage;
                $woocommerce->cart->add_fee(esc_html__('bKash Charge', 'stb'), $surcharge, true, '');
            }
        });
    }

     // Admin Column Management
    add_filter('manage_edit-shop_order_columns', function($columns) {
        $new_columns = is_array($columns) ? $columns : [];
        unset($new_columns['order_actions']);
        $new_columns['mobile_no'] = esc_html__('Send From', 'stb');
        $new_columns['order_actions'] = $columns['order_actions'];
        return $new_columns;
    });

    add_action('manage_shop_order_posts_custom_column', function($column) {
        global $post;
        if ($column == 'mobile_no') {
            echo esc_attr(pay_bKash_get_order_number($post->ID));
        }
    }, 2);
   

 // Admin Order Display Functions
add_action('woocommerce_admin_order_data_after_billing_address', function($order) {
    if (!pay_bKash_is_payment_method($order)) return;

    $number = pay_bKash_get_order_number($order);
    $ref_number = get_post_meta($order->get_id(), '_bkash_ref_number', true); // get saved reference code
    ?>
    <div class="form-field form-field-wide">
        <img src='<?php echo plugins_url("images/bkash.png", __FILE__); ?>' alt="bKash" style="max-width: 100px; height: auto;">
        <table class="wp-list-table widefat fixed striped posts">
            <tbody>
                <tr>
                    <th><strong><?php esc_html_e('Customer bKash Account Number', 'stb'); ?></strong></th>
                    <td style="font-size: 16px; font-weight: bold;">: <?php echo esc_attr($number); ?></td>
                </tr>
                <?php if (!empty($ref_number)) : ?>
                <tr>
                    <th><strong><?php esc_html_e('Reference Code', 'stb'); ?></strong></th>
                    <td style="font-size: 16px; font-weight: bold; color: #d63384;">: <?php echo esc_html($ref_number); ?></td>
                </tr>
                <?php endif; ?>
            </tbody>
        </table>
    </div>
    <?php
});


// show thank you page
add_action('woocommerce_order_details_after_customer_details', function($order) {
    if (!pay_bKash_is_payment_method($order)) return;

    $number = pay_bKash_get_order_number($order);
    $ref_number = get_post_meta($order->get_id(), '_bkash_ref_number', true); // Get reference code
    ?>
    <tr>
        <th><?php esc_html_e('Your bKash Account Number:', 'stb'); ?></th>
        <td><?php echo esc_attr($number); ?></td>
    </tr>
    <?php if (!empty($ref_number)): ?> <br>
    <tr>
        <th><?php esc_html_e('Your Reference Code:', 'stb'); ?></th>
        <td><?php echo esc_attr($ref_number); ?></td>
    </tr>
    <?php endif; ?>
    <?php
});


     // Styling
    add_action('wp_head', function() {
        if (is_checkout()) {
            ?>
            <style>
                li.wc_payment_method.payment_method_pay_bKash {
                    border: solid 2px #e7e7e7; padding: 10px; border-radius: 8px; background-color: #fff;
                }
                .payment_method_pay_bKash img { max-width: 60px !important; height: auto !important; }
            </style>
            <?php
        }
    });

    add_action('admin_head', function() {
        ?>
        <style>
            #toplevel_page_pay_bKash_settings_menu .wp-menu-image img { width: 20px !important; height: 20px !important; }
        </style>
        <?php
    });


     // Plugin Settings and Links
    add_filter("plugin_action_links_" . plugin_basename(__FILE__), function($links) {
        $settings_links = [
            '<a href="https://www.facebook.com/Labartise" target="_blank">' . esc_html__('Follow us', 'stb') . '</a>',
            '<a href="' . admin_url('admin.php?page=wc-settings&tab=checkout&section=pay_bKash') . '">' . esc_html__('Settings', 'stb') . '</a>'
        ];
        
        foreach ($settings_links as $link) {
            array_unshift($links, $link);
        }
        return $links;
    });