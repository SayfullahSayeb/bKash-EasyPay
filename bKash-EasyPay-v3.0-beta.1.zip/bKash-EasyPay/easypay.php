<?php 
/*
Plugin Name: bKash EasyPay
Plugin URI:  https://labartise.com
Description: bKash EasyPay is a manual payment gateway for WooCommerce that allows customers to pay via bKash.
Version:     2.0.0
Author:      Labartise
Author URI:  https://labartise.com
License:     GPL2
License URI: https://www.gnu.org/licenses/gpl-2.0.html
Requires PHP: 5.6
GitHub Plugin URI: https://github.com/SayfullahSayeb/bKash-EasyPay
*/

defined('ABSPATH') or die('Only a foolish person try to access directly to see this white page. :-) ');

// Plugin constants
define('pay_bKash__VERSION', '2.0.0');
define('pay_bKash__PLUGIN_DIR', plugin_dir_path(__FILE__));

// Include additional PHP files
foreach (glob(pay_bKash__PLUGIN_DIR . '*.php') as $file) {
    if ($file !== __FILE__) {
        require_once $file;
    }
}

// Get bKash number from order using multiple fallback methods
function pay_bKash_get_order_number($order_id) {
    $order = is_object($order_id) ? $order_id : wc_get_order($order_id);
    if (!$order) return '';
    
    $methods = ['_bKash_number', 'bKash_number'];
    foreach ($methods as $method) {
        $number = $order->get_meta($method, true);
        if (!empty($number)) return $number;
        
        $number = get_post_meta($order->get_id(), $method, true);
        if (!empty($number)) return $number;
    }
    return '';
}

// Check if current payment method is bKash
function pay_bKash_is_payment_method($order) {
    return $order && $order->get_payment_method() === 'pay_bKash';
}

// Validate Bangladeshi mobile number
function pay_bKash_validate_number($number) {
    return preg_match('/^01[5-9]\d{8}$/', $number);
}

/**
 * Plugin core start - Check WooCommerce activation
 */
if (in_array('woocommerce/woocommerce.php', apply_filters('active_plugins', get_option('active_plugins')))) {
    
    // Register bKash gateway
    add_filter('woocommerce_payment_gateways', function($gateways) {
        $gateways[] = 'pay_bKash';
        return $gateways;
    });

    // Initialize bKash gateway
    add_action('plugins_loaded', function() {
        
        class pay_bKash extends WC_Payment_Gateway {

            public $bKash_number, $number_type, $order_status, $instructions, $bKash_charge, $bKash_qr_code;

            public function __construct() {
                $this->id = 'pay_bKash';
                $this->title = $this->get_option('title', 'bKash P2P Gateway');
                $this->description = $this->get_option('description', 'bKash Manual Payment');
                $this->method_title = esc_html__("bKash EasyPay", "stb");
                $this->method_description = esc_html__("bKash EasyPay is a manual payment gateway for WooCommerce that allows customers to pay via bKash.", "stb");
                $this->icon = plugins_url('images/bkash.png', __FILE__);
                $this->has_fields = true;
                
                $this->pay_bKash_options_fields();
                $this->init_settings();
                
                // Initialize properties
                $options = ['bKash_number', 'number_type', 'order_status', 'instructions', 'bKash_charge', 'bKash_qr_code'];
                foreach ($options as $option) {
                    $this->$option = $this->get_option($option);
                }

                // Hook actions
                add_action('woocommerce_update_options_payment_gateways_' . $this->id, [$this, 'process_admin_options']);
                add_filter('woocommerce_thankyou_order_received_text', [$this, 'pay_bKash_thankyou_page']);
                add_action('woocommerce_email_before_order_table', [$this, 'pay_bKash_number_instructions'], 10, 3);
            }

            public function pay_bKash_options_fields() {
                $this->form_fields = [
                    'enabled' => [
                        'title' => esc_html__('Enable/Disable', "stb"),
                        'type' => 'checkbox',
                        'label' => esc_html__('bKash EasyPay Payment', "stb"),
                        'default' => 'yes'
                    ],
                    'title' => [
                        'title' => esc_html__('Title', "stb"),
                        'type' => 'text',
                        'default' => esc_html__('bKash EasyPay', "stb")
                    ],
                    'description' => [
                        'title' => esc_html__('Description', "stb"),
                        'type' => 'textarea',
                        'default' => esc_html__('Please fill out the checkout form to confirm the payment.', "stb"),
                        'desc_tip' => true
                    ],
                    'number_type' => [
                        'title' => esc_html__('bKash Account Type', "stb"),
                        'type' => 'select',
                        'class' => 'wc-enhanced-select',
                        'description' => esc_html__('Select bKash account type', "stb"),
                        'options' => [
                            'Agent' => esc_html__('Agent', "stb"),
                            'Personal' => esc_html__('Personal', "stb")
                        ],
                        'desc_tip' => true
                    ],
                    'bKash_number' => [
                        'title' => esc_html__('bKash Number', "stb"),
                        'description' => esc_html__('Add a bKash Number which will be shown in checkout page', "stb"),
                        'type' => 'number',
                        'desc_tip' => true
                    ],
                    'order_status' => [
                        'title' => esc_html__('Order Status', "stb"),
                        'type' => 'select',
                        'class' => 'wc-enhanced-select',
                        'description' => esc_html__('Choose whether status you wish after checkout.', "stb"),
                        'default' => 'wc-on-hold',
                        'desc_tip' => true,
                        'options' => wc_get_order_statuses()
                    ],
                    'bKash_charge' => [
                        'title' => esc_html__('Enable bKash Charge', "stb"),
                        'type' => 'checkbox',
                        'label' => esc_html__('Add 2% bKash "Payment" charge to net price', "stb"),
                        'description' => esc_html__('If a product price is 1000 then customer have to pay ( 1000 + 20 ) = 1020. Here 20 is bKash charge', "stb"),
                        'default' => 'no',
                        'desc_tip' => true
                    ],
                    'instructions' => [
                        'title' => esc_html__('Thank You Page Message', "stb"),
                        'type' => 'textarea',
                        'description' => esc_html__('Instructions that will be added to the thank you page and emails.', "stb"),
                        'default' => esc_html__('Thank you for your purchase! We will review it and update you as soon as possible.', "stb"),
                        'desc_tip' => true
                    ],
                    'bKash_qr_code' => [
                        'title' => esc_html__('bKash QR Code', "stb"),
                        'type' => 'bkash_qr_upload',
                        'description' => esc_html__('Upload QR code image for bKash payment', "stb"),
                        'desc_tip' => true,
                        'default' => ''
                    ]
                ];
            }

            /**
             * Generate QR upload field HTML
             */
            public function generate_bkash_qr_upload_html($key, $data) {
                $field_key = $this->get_field_key($key);
                $defaults = [
                    'title' => '',
                    'disabled' => false,
                    'class' => '',
                    'css' => '',
                    'placeholder' => '',
                    'type' => 'text',
                    'desc_tip' => false,
                    'description' => '',
                    'custom_attributes' => [],
                ];

                $data = wp_parse_args($data, $defaults);
                $value = $this->get_option($key);

                ob_start();
                ?>
                <tr valign="top">
                    <th scope="row" class="titledesc">
                        <label for="<?php echo esc_attr($field_key); ?>"><?php echo wp_kses_post($data['title']); ?> <?php echo $this->get_tooltip_html($data); // WPCS: XSS ok. ?></label>
                    </th>
                    <td class="forminp">
                        <fieldset>
                            <legend class="screen-reader-text"><span><?php echo wp_kses_post($data['title']); ?></span></legend>
                            
                            <div class="bkash-qr-upload-wrapper" style="max-width: 600px;">
                                <input 
                                    class="input-text regular-input <?php echo esc_attr($data['class']); ?>" 
                                    type="text" 
                                    name="<?php echo esc_attr($field_key); ?>" 
                                    id="<?php echo esc_attr($field_key); ?>" 
                                    style="<?php echo esc_attr($data['css']); ?> width: 100%; margin-bottom: 10px;" 
                                    value="<?php echo esc_attr($value); ?>" 
                                    placeholder="<?php echo esc_attr($data['placeholder']); ?>" 
                                    <?php disabled($data['disabled'], true); ?> 
                                    <?php echo $this->get_custom_attribute_html($data); // WPCS: XSS ok. ?>
                                    readonly
                                />
                                
                                <div class="bkash-qr-buttons" style="margin-bottom: 15px;">
                                    <button type="button" class="button button-secondary bkash-upload-qr" id="bkash_upload_qr_<?php echo esc_attr($key); ?>">
                                        <?php esc_html_e('Upload QR Code', 'stb'); ?>
                                    </button>
                                    
                                    <button type="button" class="button button-secondary bkash-remove-qr" id="bkash_remove_qr_<?php echo esc_attr($key); ?>" <?php echo empty($value) ? 'style="display:none;"' : ''; ?>>
                                        <?php esc_html_e('Remove', 'stb'); ?>
                                    </button>
                                </div>
                                
                                <?php if (!empty($value)) : ?>
                                <div class="bkash-qr-preview" id="bkash_qr_preview_<?php echo esc_attr($key); ?>" style="border: 1px solid #ddd; padding: 10px; background: #f9f9f9; border-radius: 4px; text-align: center;">
                                    <img src="<?php echo esc_url($value); ?>" alt="QR Code Preview" style="max-width: 200px; height: auto; border-radius: 4px;">
                                    <p style="margin: 10px 0 0 0; font-size: 13px; color: #666;">
                                        <?php esc_html_e('Current QR Code', 'stb'); ?>
                                    </p>
                                </div>
                                <?php else : ?>
                                <div class="bkash-qr-preview" id="bkash_qr_preview_<?php echo esc_attr($key); ?>" style="display: none; border: 1px solid #ddd; padding: 10px; background: #f9f9f9; border-radius: 4px; text-align: center;">
                                    <img src="" alt="QR Code Preview" style="max-width: 200px; height: auto; border-radius: 4px;">
                                    <p style="margin: 10px 0 0 0; font-size: 13px; color: #666;">
                                        <?php esc_html_e('QR Code Preview', 'stb'); ?>
                                    </p>
                                </div>
                                <?php endif; ?>
                            </div>
                            
                            <?php echo $this->get_description_html($data); // WPCS: XSS ok. ?>
                        </fieldset>
                    </td>
                </tr>
                <?php
                return ob_get_clean();
            }

            public function payment_fields() {
                global $woocommerce;
                
                // Display charge information if enabled
                $bKash_charge = ($this->bKash_charge == 'yes') 
                    ? esc_html__(' Note: 2% bKash "Send Money" cost will be added with the net price.', "stb") . '<br><br><strong>' 
                      . esc_html__('Total Amount:', "stb") . '</strong> ' . get_woocommerce_currency_symbol() . $woocommerce->cart->total 
                    : '';
                
                echo wpautop(wptexturize(esc_html__($this->description, "stb")) . $bKash_charge);
                
                $account_type = ($this->number_type == 'Agent') ? '(Cash Out)' : '(Send Money)';
                ?>
                <div style="margin-bottom: 10px;">
                    <span><strong>bKash <?php echo $account_type; ?>:</strong> 
                        <span id="bkash-number-display" style="font-size: 16px; font-weight: normal;"><?php echo $this->bKash_number; ?></span>
                    </span>
                    <button type="button" id="copy-bkash-number" style="margin-left: 10px; font-size: 14px; padding: 2px 8px; cursor: pointer; background: #e2136e; border-radius: 25px; color: #fff;">Copy Number</button>
                    <?php if (!empty($this->bKash_qr_code)): ?>
                        <button type="button" id="toggle-qr-code" style="margin-left: 10px; font-size: 14px; padding: 2px 8px; cursor: pointer; background: #e2136e; border-radius: 25px; color: #fff;">Show QR</button>
                    <?php endif; ?>
                </div>
                
                <?php if (!empty($this->bKash_qr_code)): ?>
                    <div id="qr-code-container" style="display: none; text-align: center; margin: 15px 0;">
                        <img src="<?php echo esc_url($this->bKash_qr_code); ?>" alt="bKash QR Code" style="max-width: 250px !important; height: auto !important; border: 2px solid #ddd; border-radius: 8px;">
                    </div>
                    <?php
                    $ref_number = WC()->session->get('bkash_ref_number');
                    if (empty($ref_number)) {
                        $ref_number = rand(1000, 9999);
                        WC()->session->set('bkash_ref_number', $ref_number);
                    }
                    ?>
                    <br>
                    <span style="font-size: 16px; font-weight: bold; color: #d63384;">
                        Reference: <?php echo esc_html($ref_number); ?>
                    </span>
                <?php endif; ?>

                <script type="text/javascript">
                    document.getElementById('copy-bkash-number').addEventListener('click', function() {
                        var bkashNumber = document.getElementById('bkash-number-display').innerText;
                        var tempInput = document.createElement('input');
                        tempInput.value = bkashNumber;
                        document.body.appendChild(tempInput);
                        tempInput.select();
                        document.execCommand('copy');
                        document.body.removeChild(tempInput);
                        this.innerText = 'Copied!';
                        var button = this;
                        setTimeout(function() { button.innerText = 'Copy Number'; }, 2000);
                    });

                    <?php if (!empty($this->bKash_qr_code)): ?>
                    document.getElementById('toggle-qr-code').addEventListener('click', function() {
                        var qrContainer = document.getElementById('qr-code-container');
                        if (qrContainer.style.display === 'none') {
                            qrContainer.style.display = 'block';
                            this.innerText = 'Hide QR';
                        } else {
                            qrContainer.style.display = 'none';
                            this.innerText = 'Show QR';
                        }
                    });
                    <?php endif; ?>
                </script>
                
                <div style="display: flex; margin-top: 15px; flex-direction: column;">
                    <label for="bKash_number" style="margin: 0; font-weight: bold;"><?php esc_html_e('Your bKash Number (used for payment):', "stb"); ?></label>
                    <input type="text" name="bKash_number" id="bKash_number" placeholder="017XXXXXXXX" style="margin-top: 5px;">
                </div>
                <?php 
            }

            public function process_payment($order_id) {
                global $woocommerce;
                $order = new WC_Order($order_id);
                
                $status = 'wc-' === substr($this->order_status, 0, 3) ? substr($this->order_status, 3) : $this->order_status;
                $order->update_status($status, esc_html__('Checkout with bKash payment. ', "stb"));
                $order->reduce_order_stock();
                $woocommerce->cart->empty_cart();

                return [
                    'result' => 'success',
                    'redirect' => $this->get_return_url($order)
                ];
            }

            public function pay_bKash_thankyou_page() {
                $order_id = get_query_var('order-received');
                $order = new WC_Order($order_id);
                
                return pay_bKash_is_payment_method($order) 
                    ? $this->instructions 
                    : esc_html__('Thank you. Your order has been received.', "stb");
            }

            public function pay_bKash_number_instructions($order, $sent_to_admin, $plain_text = false) {
                if (!pay_bKash_is_payment_method($order)) return;
                
                if ($this->instructions && !$sent_to_admin && $this->id === $order->get_payment_method()) {
                    echo wpautop(wptexturize($this->instructions)) . PHP_EOL;
                }
            }
        }
    });

    // Save reference number
    add_action('woocommerce_checkout_update_order_meta', function($order_id) {
        $order = wc_get_order($order_id);
        if (!$order || !pay_bKash_is_payment_method($order)) {
            return; 
        }

        $ref_number = WC()->session->get('bkash_ref_number');
        if ($ref_number) {
            update_post_meta($order_id, '_bkash_ref_number', $ref_number);
            WC()->session->__unset('bkash_ref_number'); 
        }
    });

    /**
     * Form Validation and Processing
     */
    add_action('woocommerce_checkout_process', function() {
        if ($_POST['payment_method'] != 'pay_bKash') return;

        $bKash_number = sanitize_text_field($_POST['bKash_number'] ?? '');

        if (empty($bKash_number)) {
            wc_add_notice(esc_html__('Please add bKash Number', 'stb'), 'error');
        } elseif (!pay_bKash_validate_number($bKash_number)) {
            wc_add_notice(esc_html__('Incorrect mobile number.', 'stb'), 'error');
        }
    });

    add_action('woocommerce_checkout_update_order_meta', function($order_id) {
        if ($_POST['payment_method'] != 'pay_bKash') return;
        
        $bKash_number = sanitize_text_field($_POST['bKash_number'] ?? '');
        if ($bKash_number) {
            update_post_meta($order_id, '_bKash_number', $bKash_number);
        }
    });

/**
     * Admin Scripts and Styles for QR Code Upload
     */
    add_action('admin_enqueue_scripts', function($hook) {
        // Check if we're on WooCommerce settings page OR our custom settings page
        $is_wc_settings = (isset($_GET['page']) && $_GET['page'] === 'wc-settings' && 
                          isset($_GET['tab']) && $_GET['tab'] === 'checkout' &&
                          isset($_GET['section']) && $_GET['section'] === 'pay_bkash');
        
        $is_custom_settings = (isset($_GET['page']) && $_GET['page'] === 'bkash-payment-settings');
        
        if (!$is_wc_settings && !$is_custom_settings) return;
            
        wp_enqueue_media();
        wp_enqueue_script('jquery');
        
        // Add custom admin styles
        wp_add_inline_style('wp-admin', '
            .bkash-qr-upload-wrapper .button {
                height: 32px;
                line-height: 30px;
                margin-right: 10px;
            }
            .bkash-qr-upload-wrapper .button .dashicons {
                font-size: 16px;
                width: 16px;
                height: 16px;
            }
            .bkash-qr-preview {
                transition: all 0.3s ease;
            }
        ');
    });

    add_action('admin_footer', function() {
        // Check if we're on WooCommerce settings page OR our custom settings page
        $is_wc_settings = (isset($_GET['page']) && $_GET['page'] === 'wc-settings' && 
                          isset($_GET['tab']) && $_GET['tab'] === 'checkout');
        
        $is_custom_settings = (isset($_GET['page']) && $_GET['page'] === 'bkash-payment-settings');
        
        if (!$is_wc_settings && !$is_custom_settings) return;
        ?>
        <script type="text/javascript">
        jQuery(document).ready(function($) {
            // Handle QR code upload
            $(document).on('click', '.bkash-upload-qr', function(e) {
                e.preventDefault();
                
                if (typeof wp === 'undefined' || typeof wp.media === 'undefined') {
                    alert('WordPress media library is not loaded properly. Please refresh the page and try again.');
                    return;
                }
                
                var button = $(this);
                var inputField = button.closest('.bkash-qr-upload-wrapper').find('input[type="text"]');
                var preview = button.closest('.bkash-qr-upload-wrapper').find('.bkash-qr-preview');
                var removeBtn = button.closest('.bkash-qr-upload-wrapper').find('.bkash-remove-qr');
                
                var frame = wp.media({
                    title: 'Select QR Code Image',
                    button: {
                        text: 'Use This Image'
                    },
                    multiple: false,
                    library: {
                        type: 'image'
                    }
                });
                
                frame.on('select', function() {
                    var attachment = frame.state().get('selection').first().toJSON();
                    
                    // Update input field
                    inputField.val(attachment.url).trigger('change');
                    
                    // Update preview
                    preview.find('img').attr('src', attachment.url);
                    preview.show();
                    
                    // Show remove button
                    removeBtn.show();
                });
                
                frame.open();
            });
            
            // Handle QR code removal
            $(document).on('click', '.bkash-remove-qr', function(e) {
                e.preventDefault();
                
                var button = $(this);
                var inputField = button.closest('.bkash-qr-upload-wrapper').find('input[type="text"]');
                var preview = button.closest('.bkash-qr-upload-wrapper').find('.bkash-qr-preview');
                
                // Clear input field
                inputField.val('').trigger('change');
                
                // Hide preview and remove button
                preview.hide();
                button.hide();
            });
        });
        </script>
        <?php
    });

} else {
    // WooCommerce not active - show admin notice and deactivate
    add_action('admin_notices', function() {
        ?>
        <div class="notice notice-error">
            <p><a href="http://wordpress.org/extend/plugins/woocommerce/"><?php esc_html_e('WooCommerce', 'stb'); ?></a> 
               <?php esc_html_e('plugin needs to be active if you want to use bKash plugin.', 'stb'); ?></p>
        </div>
        <?php
    });
    
    add_action('admin_init', function() {
        deactivate_plugins(plugin_basename(__FILE__));
        unset($_GET['activate']);
    });
}
?>