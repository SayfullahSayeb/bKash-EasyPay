<?php
if (!defined('ABSPATH')) exit;

// Create custom table for SMS logs on plugin activation
register_activation_hook(__FILE__, function() {
    global $wpdb;
    $table = $wpdb->prefix . 'bkash_payments';
    $charset_collate = $wpdb->get_charset_collate();

    $sql = "CREATE TABLE IF NOT EXISTS $table (
        id BIGINT(20) UNSIGNED NOT NULL AUTO_INCREMENT,
        reference VARCHAR(100) NOT NULL,
        sender VARCHAR(50) DEFAULT '',
        amount DECIMAL(15,2) NOT NULL,
        trxid VARCHAR(50) DEFAULT '',
        message TEXT,
        timestamp DATETIME DEFAULT CURRENT_TIMESTAMP,
        status VARCHAR(20) DEFAULT 'received',
        PRIMARY KEY  (id)
    ) $charset_collate;";

    require_once(ABSPATH . 'wp-admin/includes/upgrade.php');
    dbDelta($sql);
});

// Parse SMS text
function easypay_parse_sms($message) {
    $data = [];

    // Extract amount
    if (preg_match('/Tk\s*([\d,.]+)/i', $message, $match)) {
        $data['amount'] = floatval(str_replace(',', '', $match[1]));
    }
    // Extract sender number
    if (preg_match('/from\s*(\d+)/i', $message, $match)) {
        $data['sender'] = $match[1];
    }
    // Extract reference number
    if (preg_match('/Ref\s*(\d+)/i', $message, $match)) {
        $data['reference'] = $match[1];
    }
    // Extract TrxID
    if (preg_match('/TrxID\s*([A-Z0-9]+)/i', $message, $match)) {
        $data['trxid'] = $match[1];
    }
    // Extract time
    if (preg_match('/at\s*([\d\/\s:]+)/i', $message, $match)) {
        $dt = DateTime::createFromFormat('d/m/Y H:i', trim($match[1]));
        $data['time'] = $dt ? $dt->format('Y-m-d H:i:s') : current_time('mysql');
    }

    return $data;
}

// Callback to receive and store SMS
function easypay_bkash_sms_receiver($request) {
    global $wpdb;
    $table = $wpdb->prefix . 'bkash_payments';

    $data = $request->get_json_params();
    $message = sanitize_text_field($data['message'] ?? '');

    if (empty($message)) {
        return ['success' => false, 'msg' => 'No message provided'];
    }

    $parsed = easypay_parse_sms($message);

    if (empty($parsed['reference']) || empty($parsed['amount'])) {
        return ['success' => false, 'msg' => 'Invalid SMS format'];
    }

    $wpdb->insert($table, [
        'reference' => $parsed['reference'],
        'sender'    => $parsed['sender'] ?? '',
        'amount'    => $parsed['amount'],
        'trxid'     => $parsed['trxid'] ?? '',
        'message'   => $message,
        'timestamp' => $parsed['time'] ?? current_time('mysql'),
        'status'    => 'received'
    ]);

    return [
        'success' => true,
        'data' => [
            'sender' => $parsed['sender'] ?? '',
            'ref'    => $parsed['reference'] ?? '',
            'amount' => $parsed['amount'] ?? '',
            'trxid'  => $parsed['trxid'] ?? '',
        ]
    ];
}

// Render SMS Logs in Admin
function easypay_render_sms_logs() {
    global $wpdb;
    $table = $wpdb->prefix . 'bkash_payments';

    // Search
    $search = isset($_GET['s']) ? sanitize_text_field($_GET['s']) : '';

    // Pagination settings
    $per_page = 20;
    $paged = isset($_GET['paged']) ? max(1, intval($_GET['paged'])) : 1;
    $offset = ($paged - 1) * $per_page;

    // Prepare SQL with search filter
    $where = '';
    if (!empty($search)) {
        $like = '%' . $wpdb->esc_like($search) . '%';
        $where = $wpdb->prepare("WHERE reference LIKE %s OR sender LIKE %s", $like, $like);
    }

    // Total logs count
    $total_logs = $wpdb->get_var("SELECT COUNT(*) FROM $table $where");

    // Fetch logs for current page
    $logs = $wpdb->get_results($wpdb->prepare(
        "SELECT * FROM $table $where ORDER BY id DESC LIMIT %d OFFSET %d",
        $per_page, $offset
    ));

    // CSS
    echo '<style>
    @import url("https://fonts.googleapis.com/css2?family=SF+Pro+Display:wght@400;500;600;700&display=swap");
    .wrap{font-family:-apple-system,BlinkMacSystemFont,"SF Pro Display","Segoe UI",Roboto,sans-serif; margin-right:10px;}
.wrap h1{font-size:34px;font-weight:700;color:#000;margin-bottom:20px;letter-spacing:-0.5px}
    .header{display:flex;justify-content:space-between;align-items:center;margin-bottom:24px;background:#fff;padding:16px 20px;border-radius:16px;box-shadow:0 2px 10px rgba(0,0,0,0.04);}
    .title{font-size:34px;font-weight:700;color:#000;margin:0 0 24px 0;letter-spacing:-0.5px;}
    .search-form{display:flex;gap:12px;align-items:center;}
    .search-form input[type="text"]{padding:12px 16px;border:none;background:#f2f2f7;border-radius:12px;font-size:16px;width:280px;transition:all 0.2s;outline:none;}
    .search-form input[type="text"]:focus{background:#e5e5ea;box-shadow:0 0 0 4px rgba(0,122,255,0.1);}
    .search-form input[type="text"]::placeholder{color:#8e8e93;}
    .search-form .button{background:#007aff;color:#fff;border:none;padding:12px 24px;border-radius:12px;cursor:pointer;font-size:16px;font-weight:500;transition:all 0.2s;box-shadow:0 2px 8px rgba(0,122,255,0.2);}
	.search-form .button:hover{color:#FFF;}
    .search-form .button:hover{background:#0051d5;transform:translateY(-1px);box-shadow:0 4px 12px rgba(0,122,255,0.3);}
    .search-form .button:active{transform:translateY(0);}
    .pagination{display:flex;gap:8px;align-items:center;}
    .pagination span{color:#8e8e93;font-size:14px;margin-right:8px;}
    .pagination a{padding:8px 14px;background:#fff;border:1px solid #e5e5ea;text-decoration:none;color:#007aff;border-radius:10px;font-size:14px;font-weight:500;transition:all 0.2s;}
    .pagination a:hover{background:#f2f2f7;border-color:#007aff;}
    .pagination a.current-page{background:#007aff;color:#fff;border-color:#007aff;box-shadow:0 2px 8px rgba(0,122,255,0.2);}
    .table-container{background:#fff;border-radius:16px;overflow:hidden;box-shadow:0 2px 10px rgba(0,0,0,0.04);}
    .table{width:100%;border-collapse:collapse;}
    .table thead{background:#f2f2f7;border-bottom:1px solid #e5e5ea;}
    .table th{padding:16px 20px;text-align:left;font-weight:600;font-size:13px;color:#8e8e93;text-transform:uppercase;letter-spacing:0.5px;}
    .table td{padding:16px 20px;border-bottom:1px solid #f2f2f7;font-size:15px;color:#000;}
    .table tbody tr{transition:background 0.2s;}
    .table tbody tr:hover{background:#f9f9f9;}
    .table tbody tr:last-child td{border-bottom:none;}
    .amount{font-weight:600;color:#34c759;}
    .ref{font-weight:500;color:#007aff;}
    .time{color:#8e8e93;font-size:14px;}
    .empty{text-align:center;padding:60px 20px;color:#8e8e93;font-size:17px;}
    .empty::before{content:"📭";display:block;font-size:48px;margin-bottom:16px;}
    .badge{display:inline-block;padding:4px 8px;background:#007aff;color:#fff;border-radius:6px;font-size:12px;font-weight:600;margin-left:8px;}
    </style>';

    echo '<div class="wrap">';
    echo '<h1 class="title">bKash SMS Logs</h1>';
    echo '<div class="wrap">';

    // Header with search and pagination
    echo '<div class="header">';
    
    // Search form (left side)
    echo '<form method="get" class="search-form">';
    echo '<input type="hidden" name="page" value="bkash-sms-logs">';
    echo '<input type="text" name="s" value="' . esc_attr($search) . '" placeholder="Search reference or sender...">';
    echo '<input type="submit" class="button" value="Search">';
    echo '</form>';

    // Pagination (right side)
    $total_pages = ceil($total_logs / $per_page);
    if ($total_pages > 1) {
        echo '<div class="pagination">';
        echo '<span>Page</span>';
        for ($i = 1; $i <= $total_pages; $i++) {
            $class = ($i === $paged) ? 'current-page' : '';
            $url = admin_url('admin.php?page=bkash-sms-logs&paged=' . $i);
            if (!empty($search)) {
                $url .= '&s=' . urlencode($search);
            }
            echo '<a class="' . $class . '" href="' . esc_url($url) . '">' . $i . '</a>';
        }
        echo '</div>';
    }
    
    echo '</div>'; // End header

    // Table
    echo '<div class="table-container">';
    echo '<table class="table">';
    echo '<thead><tr>
            <th>ID</th>
            <th>Time</th>
            <th>Reference</th>
            <th>Sender</th>
            <th>Amount</th>
            <th>TrxID</th>
            <th>Message</th>
          </tr></thead><tbody>';

    if (!empty($logs)) {
        foreach ($logs as $log) {
            $time = date('M d, Y • h:i A', strtotime($log->timestamp));
            echo "<tr>
                <td>{$log->id}</td>
                <td class='time'>{$time}</td>
                <td><span class='ref'>{$log->reference}</span></td>
                <td>{$log->sender}</td>
                <td class='amount'>৳ " . number_format($log->amount, 2) . "</td>
                <td>{$log->trxid}</td>
                <td>{$log->message}</td>
            </tr>";
        }
    } else {
        echo '<tr><td colspan="7" class="empty">No SMS logs found</td></tr>';
    }

    echo '</tbody></table>';
    echo '</div>'; // End table container
    echo '</div>'; // End wrap
    echo '</div>'; // End wrap
}