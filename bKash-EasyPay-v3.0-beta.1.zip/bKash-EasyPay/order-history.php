<?php

// Get status color for order status
function pay_bKash_get_status_color($status) {
    $colors = [
        'pending' => '#f56e28', 'processing' => '#8bc34a', 'on-hold' => '#ff9800',
        'completed' => '#4caf50', 'cancelled' => '#000000', 'refunded' => '#9e9e9e', 'failed' => '#d63638'
    ];
    return $colors[$status] ?? '#666';
}

/**
 * Transaction Information Page
 */
function pay_bKash_transactions_page() {
    $search = sanitize_text_field($_GET['search'] ?? '');
    $per_page = 20;
    $current_page = max(1, intval($_GET['paged'] ?? 1));
    $offset = ($current_page - 1) * $per_page;

    // Get all order IDs (for total count) - exclude refunds
    $total_all_order_ids = wc_get_orders([
        'limit' => -1, 
        'return' => 'ids',
        'type' => 'shop_order' // Only get regular orders, not refunds
    ]);
    $total_all_orders = count($total_all_order_ids);

    // Handle search
    $search_order_ids = [];
    if (!empty($search)) {
        foreach ($total_all_order_ids as $order_id) {
            $order = wc_get_order($order_id);
            if (!$order) continue;
            
            // Skip refund orders
            if ($order->get_type() === 'shop_order_refund') continue;

            $billing_name = $order->get_billing_first_name() . ' ' . $order->get_billing_last_name();
            $payment_method = $order->get_payment_method();
            $bkash_number = ($payment_method === 'pay_bKash') ? pay_bKash_get_order_number($order) : '';
            $ref_number = get_post_meta($order_id, '_bkash_ref_number', true);

            if (stripos($order_id, $search) !== false
                || stripos($billing_name, $search) !== false
                || (!empty($bkash_number) && stripos($bkash_number, $search) !== false)
                || (!empty($ref_number) && stripos($ref_number, $search) !== false)) {
                $search_order_ids[] = $order_id;
            }
        }
        $search_order_ids = array_unique($search_order_ids);
    }

    // Prepare arguments for fetching orders
    $args = [
        'limit' => $per_page,
        'offset' => $offset,
        'orderby' => 'date',
        'order' => 'DESC',
        'type' => 'shop_order' // Only get regular orders, not refunds
    ];

    if (!empty($search_order_ids)) {
        $args['post__in'] = $search_order_ids;
    }

    $orders = wc_get_orders($args);
    $total_orders = !empty($search_order_ids) ? count($search_order_ids) : $total_all_orders;
    $total_pages = ceil($total_orders / $per_page);

    ?>
    <div class="wrap style-wrap">
        <div class="header">
            <h1><?php esc_html_e('Order History', 'stb'); ?></h1>
            <a href="<?php echo wp_nonce_url(admin_url('admin.php?page=pay_bKash_transactions&action=export_csv'), 'export_bkash_csv'); ?>" 
               class="c-button c-button-small">
                <?php esc_html_e('Export CSV', 'stb'); ?>
            </a>
        </div>

        <div class="controls-bar">
            <div class="search-container">
                <form method="get" class="search-form">
                    <input type="hidden" name="page" value="pay_bKash_transactions">
                    <div class="search-wrapper">
                        <input type="text" id="search" name="search" value="<?php echo esc_attr($search); ?>" 
                               placeholder="<?php esc_attr_e('Search orders...', 'stb'); ?>" 
                               class="search-input">
                        <?php if (!empty($search)): ?>
                        <?php endif; ?>
                        <button type="submit" class="search-c-button">
                            <svg width="20" height="20" viewBox="0 0 20 20" fill="none">
                                <path d="M9 17A8 8 0 1 0 9 1a8 8 0 0 0 0 16zM19 19l-4.35-4.35" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"/>
                            </svg>
                        </button>
                    </div>
                </form>
            </div>
            
            <?php if ($total_pages > 1) : ?>
                <div class="pagination">
                    <?php
                    // Previous button
                    if ($current_page > 1) : ?>
                        <a href="<?php echo admin_url('admin.php?page=pay_bKash_transactions&paged=' . ($current_page - 1) . ($search ? '&search=' . urlencode($search) : '')); ?>" 
                           class="page-btn page-prev">
                            <svg width="8" height="14" viewBox="0 0 8 14" fill="none">
                                <path d="M7 1L1 7l6 6" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"/>
                            </svg>
                        </a>
                    <?php endif; ?>
                    
                    <div class="page-numbers">
                        <?php
                        // Calculate page range
                        $range = 2;
                        $start = max(1, $current_page - $range);
                        $end = min($total_pages, $current_page + $range);
                        
                        // First page
                        if ($start > 1) {
                            echo '<a href="' . admin_url('admin.php?page=pay_bKash_transactions&paged=1' . ($search ? '&search=' . urlencode($search) : '')) . '" class="page-number">1</a>';
                            if ($start > 2) echo '<span class="page-dots">...</span>';
                        }
                        
                        // Page numbers
                        for ($i = $start; $i <= $end; $i++) {
                            $class = ($i == $current_page) ? 'page-number active' : 'page-number';
                            echo '<a href="' . admin_url('admin.php?page=pay_bKash_transactions&paged=' . $i . ($search ? '&search=' . urlencode($search) : '')) . '" class="' . $class . '">' . $i . '</a>';
                        }
                        
                        // Last page
                        if ($end < $total_pages) {
                            if ($end < $total_pages - 1) echo '<span class="page-dots">...</span>';
                            echo '<a href="' . admin_url('admin.php?page=pay_bKash_transactions&paged=' . $total_pages . ($search ? '&search=' . urlencode($search) : '')) . '" class="page-number">' . $total_pages . '</a>';
                        }
                        ?>
                    </div>
                    
                    <?php
                    // Next button
                    if ($current_page < $total_pages) : ?>
                        <a href="<?php echo admin_url('admin.php?page=pay_bKash_transactions&paged=' . ($current_page + 1) . ($search ? '&search=' . urlencode($search) : '')); ?>" 
                           class="page-btn page-next">
                            <svg width="8" height="14" viewBox="0 0 8 14" fill="none">
                                <path d="M1 1l6 6-6 6" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"/>
                            </svg>
                        </a>
                    <?php endif; ?>
                </div>
            <?php endif; ?>
        </div>

        <div class="table-container">
            <table class="table">
                <thead>
                    <tr>
                        <th><?php esc_html_e('Order ID', 'stb'); ?></th>
                        <th><?php esc_html_e('Billing Name', 'stb'); ?></th>
                        <th><?php esc_html_e('Reference Number', 'stb'); ?></th>
                        <th><?php esc_html_e('bKash Number', 'stb'); ?></th>
                        <th><?php esc_html_e('Amount', 'stb'); ?></th>
                        <th><?php esc_html_e('Payment Method', 'stb'); ?></th>
                        <th><?php esc_html_e('Date', 'stb'); ?></th>
                        <th><?php esc_html_e('Order Status', 'stb'); ?></th>
                        <th><?php esc_html_e('Action', 'stb'); ?></th>
                    </tr>
                </thead>
                <tbody>
                    <?php if (!empty($orders)) : ?>
                        <?php foreach ($orders as $order) :
                            // Skip if this is a refund order
                            if ($order->get_type() === 'shop_order_refund') continue;
                            
                            $order_id = $order->get_id();
                            $billing_name = $order->get_billing_first_name() . ' ' . $order->get_billing_last_name();
                            $payment_method = $order->get_payment_method_title() ?: $order->get_payment_method();
                            $bkash_number = ($order->get_payment_method() === 'pay_bKash') ? pay_bKash_get_order_number($order) : '';
                            $ref_number = get_post_meta($order_id, '_bkash_ref_number', true);
                            $order_total = $order->get_total();
                            $order_date = $order->get_date_created();
                            $order_status = $order->get_status();
                            $status_name = wc_get_order_status_name($order_status);
                        ?>
                        <tr>
                            <td><strong>#<?php echo $order_id; ?></strong></td>
                            <td><?php echo esc_html($billing_name); ?></td>
                            <td><?php echo $ref_number ?: '<em class="na">—</em>'; ?></td>
                            <td><?php echo $bkash_number ?: '<em class="na">—</em>'; ?></td>
                            <td><?php echo wc_price($order_total); ?></td>
                            <td><?php echo esc_html($payment_method); ?></td>
                            <td><?php echo $order_date ? $order_date->date('Y-m-d H:i:s') : ''; ?></td>
                            <td>
                                <span class="status-badge" 
                                      style="background-color:<?php echo pay_bKash_get_status_color($order_status); ?>;">
                                    <?php echo esc_html($status_name); ?>
                                </span>
                            </td>
                            <td>
                                <a href="<?php echo admin_url('post.php?post=' . $order_id . '&action=edit'); ?>" 
                                   class="c-button c-button-small">
                                    <?php esc_html_e('View', 'stb'); ?>
                                </a>
                            </td>
                        </tr>
                        <?php endforeach; ?>
                    <?php else : ?>
                        <tr>
                            <td colspan="9" class="empty-state">
                                <svg width="64" height="64" viewBox="0 0 64 64" fill="none" style="margin-bottom:16px;">
                                    <circle cx="32" cy="32" r="32" fill="#F2F2F7"/>
                                    <path d="M32 22v10m0 6h.01M44 32c0 6.627-5.373 12-12 12s-12-5.373-12-12 5.373-12 12-12 12 5.373 12 12z" stroke="#8E8E93" stroke-width="2.5" stroke-linecap="round" stroke-linejoin="round"/>
                                </svg>
                                <p><?php esc_html_e('No transactions found', 'stb'); ?></p>
                                <?php if (!empty($search)): ?>
                                    <p style="font-size:15px;color:#8E8E93;margin-top:8px"><?php esc_html_e('Try adjusting your search terms', 'stb'); ?></p>
                                <?php endif; ?>
                            </td>
                        </tr>
                    <?php endif; ?>
                </tbody>
            </table>
        </div>

        <style>
.style-wrap{font-family:-apple-system,BlinkMacSystemFont,"SF Pro Display","SF Pro Text","Helvetica Neue",Helvetica,Arial,sans-serif;color:#000;max-width:100%;margin:0;padding-right:20px}
.header{display:flex;justify-content:space-between;align-items:center;margin-bottom:24px}
.header h1{font-size:34px;font-weight:700;margin:0;letter-spacing:-0.5px}
.c-button{display:inline-flex;align-items:center;justify-content:center;padding:10px 20px;border-radius:10px;font-size:15px;font-weight:600;text-decoration:none;border:none;cursor:pointer;transition:all 0.2s;white-space:nowrap}
.c-button-small{padding:6px 16px;font-size:13px;background:#007AFF;color:#fff;border-radius:6px}
.c-button-small:hover{background:#0051D5;color:#fff;transform:scale(0.98)}
.controls-bar{display:flex;justify-content:space-between;align-items:center;margin-bottom:20px;gap:20px}
.search-container{flex:1;max-width:400px}
.search-form{width:100%}
.search-wrapper{position:relative;display:flex;align-items:center}
.search-input{width:100%;padding:12px 120px 12px 16px;border:none;border-radius:12px;background:#F2F2F7;font-size:16px;font-weight:400;outline:none;transition:all 0.2s;-webkit-appearance:none}
.search-input:focus{background:#E5E5EA;box-shadow:0 0 0 4px rgba(0,122,255,0.1)}
.search-input::placeholder{color:#8E8E93}
.search-c-button{display:flex;align-items:center;justify-content:center;padding:8px 16px; margin-left:5px;background:#007AFF;color:#fff;border:none;border-radius:8px;cursor:pointer;transition:all 0.2s;font-size:14px;font-weight:600}
.search-c-button svg{width:18px;height:18px}
.pagination{display:flex;align-items:center;gap:8px}
.page-btn{display:flex;align-items:center;justify-content:center;width:36px;height:36px;border-radius:10px;background:#F2F2F7;color:#007AFF;text-decoration:none;transition:all 0.2s}
.page-btn:hover{background:#E5E5EA;transform:scale(0.95)}
.page-numbers{display:flex;align-items:center;gap:4px}
.page-number{display:flex;align-items:center;justify-content:center;min-width:36px;height:36px;padding:0 12px;border-radius:10px;background:#F2F2F7;color:#000;text-decoration:none;font-size:15px;font-weight:500;transition:all 0.2s}
.page-number:hover{background:#E5E5EA}
.page-number.active{background:#007AFF;color:#fff}
.page-number.active:hover{background:#0051D5}
.page-dots{display:flex;align-items:center;justify-content:center;width:36px;height:36px;color:#8E8E93;font-size:15px;font-weight:500}
.table-container{background:#fff;border-radius:12px;overflow:hidden;box-shadow:0 1px 3px rgba(0,0,0,0.1),0 1px 2px rgba(0,0,0,0.06)}
.table{width:100%;border-collapse:collapse}
.table thead{background:#F9F9F9;border-bottom:1px solid #E5E5EA}
.table th{padding:14px 16px;text-align:left;font-size:13px;font-weight:600;color:#48484A;text-transform:uppercase;letter-spacing:0.5px}
.table td{padding:16px;border-bottom:1px solid #F2F2F7;font-size:15px;color:#1C1C1E}
.table tbody tr:last-child td{border-bottom:none}
.table tbody tr{transition:background 0.2s}
.table tbody tr:hover{background:#FAFAFA}
.na{color:#8E8E93;font-style:normal;font-weight:400}
.status-badge{display:inline-flex;align-items:center;padding:5px 12px;border-radius:14px;font-size:12px;font-weight:600;color:#fff;text-transform:capitalize;letter-spacing:0.3px}
.empty-state{text-align:center;padding:80px 20px;color:#8E8E93}
.empty-state p{margin:0;font-size:17px;font-weight:500}
@media(max-width:768px){
.header{flex-direction:column;align-items:flex-start;gap:16px}
.controls-bar{flex-direction:column;align-items:stretch}
.search-container{max-width:100%}
.search-input{padding:12px 110px 12px 16px}
.search-c-button{padding:6px 12px;font-size:13px}
.pagination{align-self:center;margin-top:12px}
.page-btn{width:32px;height:32px}
.page-number{min-width:32px;height:32px;padding:0 10px;font-size:14px}
.table{font-size:14px}
.table th,.table td{padding:12px 10px}
.c-button-small{font-size:12px;padding:5px 12px}
.table-container{border-radius:8px}
}
</style>
</div>
<?php
}

/**
 * CSV Export Handler
 */
add_action('admin_init', function() {
    if (!isset($_GET['action']) || $_GET['action'] !== 'export_csv') return;
    if (!isset($_GET['_wpnonce']) || !wp_verify_nonce($_GET['_wpnonce'], 'export_bkash_csv')) return;

    $orders = wc_get_orders([
        'limit' => -1,
        'type' => 'shop_order' // Only get regular orders, not refunds
    ]);
    
    header('Content-Type: text/csv');
    header('Content-Disposition: attachment; filename="orders.csv"');

    $output = fopen('php://output', 'w');
    fputcsv($output, ['Order ID', 'Billing Name', 'Payment Method', 'bKash Number', 'Reference Number', 'Amount', 'Date', 'Order Status']);

    foreach ($orders as $order) {
        // Skip refund orders
        if ($order->get_type() === 'shop_order_refund') continue;
        
        $order_id = $order->get_id();
        $billing_name = $order->get_billing_first_name() . ' ' . $order->get_billing_last_name();
        $payment_method = $order->get_payment_method_title();
        $bkash_number = ($order->get_payment_method() === 'pay_bKash') ? pay_bKash_get_order_number($order) : '';
        $ref_number = get_post_meta($order_id, '_bkash_ref_number', true);
        $amount = $order->get_total();
        $date = $order->get_date_created() ? $order->get_date_created()->date('Y-m-d H:i:s') : '';
        $status = wc_get_order_status_name($order->get_status());

        fputcsv($output, [$order_id, $billing_name, $payment_method, $bkash_number, $ref_number, $amount, $date, $status]);
    }
    fclose($output);
    exit;
});