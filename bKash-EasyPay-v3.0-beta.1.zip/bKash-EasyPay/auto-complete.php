<?php
// Hook into order status changes
add_action('woocommerce_order_status_changed', 'auto_complete_bkash_orders_on_match', 10, 4);
add_action('woocommerce_payment_complete', 'auto_complete_bkash_order_on_payment');
add_action('woocommerce_thankyou', 'auto_complete_bkash_order_on_thankyou', 10, 1);

/**
 * Auto-complete on payment complete
 */
function auto_complete_bkash_order_on_payment($order_id) {
    $order = wc_get_order($order_id);
    if (!$order || $order->get_payment_method() !== 'pay_bKash') {
        return;
    }
    
    auto_complete_bkash_order_if_matched($order);
}

/**
 * Auto-complete on thank you page
 */
function auto_complete_bkash_order_on_thankyou($order_id) {
    $order = wc_get_order($order_id);
    if (!$order || $order->get_payment_method() !== 'pay_bKash') {
        return;
    }
    
    auto_complete_bkash_order_if_matched($order);
}

/**
 * Auto-complete when order status changes
 */
function auto_complete_bkash_orders_on_match($order_id, $from_status, $to_status, $order) {
    // Only process if moving to processing or on-hold status
    if (!in_array($to_status, array('processing', 'on-hold'))) {
        return;
    }
    
    if (!$order || $order->get_payment_method() !== 'pay_bKash') {
        return;
    }
    
    auto_complete_bkash_order_if_matched($order);
}

/**
 * Check and auto-complete order if SMS matches
 */
function auto_complete_bkash_order_if_matched($order) {
    // Skip if already completed
    if ($order->get_status() === 'completed') {
        return;
    }
    
    $order_id = $order->get_id();
    $order_total = floatval($order->get_total());
    $ref_number = get_post_meta($order_id, '_bkash_ref_number', true);
    $customer_bkash = get_post_meta($order_id, '_bKash_number', true);
    
    // Skip if no reference number
    if (empty($ref_number)) {
        return;
    }
    
    // Get SMS data
    $sms_data = get_matching_bkash_sms($ref_number, $customer_bkash, $order_total);
    
    if ($sms_data && $sms_data['all_match']) {
        // Complete the order
        $order->update_status('completed', sprintf(
            'Payment auto-verified via SMS match. Ref: %s, Amount: %s, From: %s',
            $sms_data['reference'],
            $sms_data['amount'],
            $sms_data['sender']
        ));
        
        // Save verification details
        update_post_meta($order_id, '_bkash_auto_completed', 'yes');
        update_post_meta($order_id, '_bkash_verification_time', current_time('mysql'));
        
        // Update SMS log status if table exists
        global $wpdb;
        $sms_table = $wpdb->prefix . 'bkash_payments';
        if ($wpdb->get_var("SHOW TABLES LIKE '$sms_table'") === $sms_table) {
            $wpdb->update($sms_table, 
                ['status' => 'auto_completed_order_' . $order_id],
                ['reference' => $ref_number],
                ['%s'],
                ['%s']
            );
        }
    }
}

/**
 * Get matching SMS data
 */
function get_matching_bkash_sms($ref_number, $customer_bkash, $order_total) {
    global $wpdb;
    
    $table_name = $wpdb->prefix . 'bkash_payments';
    
    // Check if table exists
    if ($wpdb->get_var("SHOW TABLES LIKE '$table_name'") !== $table_name) {
        return false;
    }
    
    // Get SMS with matching reference
    $sms = $wpdb->get_row($wpdb->prepare(
        "SELECT * FROM $table_name WHERE reference = %s ORDER BY id DESC LIMIT 1",
        trim($ref_number)
    ));
    
    if (!$sms) {
        return false;
    }
    
    // Normalize phone numbers (remove country code)
    $normalized_customer = preg_replace('/^(\+88|88)/', '', trim($customer_bkash));
    $normalized_sender = preg_replace('/^(\+88|88)/', '', trim($sms->sender));
    
    // Check all matches
    $ref_match = (trim($sms->reference) === trim($ref_number));
    $sender_match = ($normalized_sender === $normalized_customer);
    $amount_match = (abs(floatval($sms->amount) - floatval($order_total)) < 0.01);
    
    if ($ref_match && $sender_match && $amount_match) {
        return array(
            'reference' => $sms->reference,
            'sender' => $sms->sender,
            'amount' => $sms->amount,
            'trxid' => $sms->trxid ?? '',
            'all_match' => true
        );
    }
    
    return false;
}

/**
 * Optional: Run auto-completion check on all pending orders periodically
 * This can be triggered via WP Cron or manually
 */
function check_all_pending_bkash_orders_for_auto_completion() {
    $orders = wc_get_orders(array(
        'limit' => -1,
        'status' => array('wc-pending', 'wc-processing', 'wc-on-hold'),
        'payment_method' => 'pay_bKash'
    ));
    
    foreach ($orders as $order) {
        auto_complete_bkash_order_if_matched($order);
    }
}

// Optional: Schedule periodic check every 5 minutes
add_action('init', function() {
    if (!wp_next_scheduled('check_bkash_orders_for_completion')) {
        wp_schedule_event(time(), 'five_minutes', 'check_bkash_orders_for_completion');
    }
});

add_filter('cron_schedules', function($schedules) {
    $schedules['five_minutes'] = array(
        'interval' => 300,
        'display' => __('Every Five Minutes')
    );
    return $schedules;
});

add_action('check_bkash_orders_for_completion', 'check_all_pending_bkash_orders_for_auto_completion');