<?php

// ===========================
// Generate API key
// ===========================
function bkash_sms_api_generate_key() {
    return substr(str_shuffle('0123456789ABCDEFGHIJKLMNOPQRSTUVWXYZ'), 0, 10);
}

// ===========================
// Settings Page Callback
// ===========================
function bkash_sms_api_settings_page() {
    // Save new API key if requested
    if (isset($_POST['bkash_generate_key'])) {
        $new_key = bkash_sms_api_generate_key();
        update_option('bkash_sms_api_key', $new_key);
        echo '<div class="success-banner">
                <span class="success-icon">✓</span>
                <span>New API Key generated successfully</span>
              </div>';
    }

    $api_key = get_option('bkash_sms_api_key');
    if (!$api_key) {
        $api_key = bkash_sms_api_generate_key();
        update_option('bkash_sms_api_key', $api_key);
    }

    $api_url = rest_url('easypay/v1/sms');
    ?>
    
    <style>
    @import url("https://fonts.googleapis.com/css2?family=SF+Pro+Display:wght@400;500;600;700&display=swap");
    .settings-wrap{font-family:-apple-system,BlinkMacSystemFont,"SF Pro Display","Segoe UI",Roboto,sans-serif;background:#f2f2f7;border-radius:20px;margin:20px 0;max-width:900px;}
.wrap h1{font-size:34px;font-weight:700;color:#000;margin-bottom:20px;letter-spacing:-0.5px}
    .settings-title{font-size:34px;font-weight:700;color:#000;margin:0 0 32px 0;letter-spacing:-0.5px;}
    .section{background:#fff;border-radius:16px;padding:24px;margin-bottom:20px;box-shadow:0 2px 10px rgba(0,0,0,0.04);}
    .section-title{font-size:20px;font-weight:600;color:#000;margin:0 0 16px 0;display:flex;align-items:center;gap:8px;}
    .section-title::before{content:"";width:4px;height:20px;background:#007aff;border-radius:2px;}
    .input-group{display:flex;gap:12px;align-items:center;margin-bottom:16px;}
    .input{padding:14px 16px;border:none;background:#f2f2f7;border-radius:12px;font-size:16px;flex:1;font-family:monospace;color:#000;transition:all 0.2s;outline:none;}
    .input:focus{background:#e5e5ea;box-shadow:0 0 0 4px rgba(0,122,255,0.1);}
    .c-button{background:#007aff;color:#fff;border:none;padding:12px 24px;border-radius:12px;cursor:pointer;font-size:16px;font-weight:500;transition:all 0.2s;box-shadow:0 2px 8px rgba(0,122,255,0.2);white-space:nowrap;}
    .c-button:hover{background:#0051d5;transform:translateY(-1px);box-shadow:0 4px 12px rgba(0,122,255,0.3);}
    .c-button:active{transform:translateY(0);}
    .c-button-primary{background:#34c759;box-shadow:0 2px 8px rgba(52,199,89,0.2);}
    .c-button-primary:hover{background:#2fb54a;box-shadow:0 4px 12px rgba(52,199,89,0.3);}
    .instructions{background:#fff;border-radius:16px;padding:24px;box-shadow:0 2px 10px rgba(0,0,0,0.04);}
    .instructions ol{margin:0;padding:0;list-style:none;counter-reset:step-counter;}
    .instructions li{position:relative;padding-left:48px;margin-bottom:24px;font-size:16px;line-height:1.6;color:#000;counter-increment:step-counter;}
    .instructions li::before{content:counter(step-counter);position:absolute;left:0;top:0;width:32px;height:32px;background:#007aff;color:#fff;border-radius:50%;display:flex;align-items:center;justify-content:center;font-weight:600;font-size:14px;}
    .instructions ul{margin:12px 0 0 0;padding:0;list-style:none;}
    .instructions ul li{padding-left:0;margin-bottom:16px;counter-increment:none;}
    .instructions ul li::before{display:none;}
    .label{font-weight:600;color:#000;margin-right:8px;}
    .value{background:#f2f2f7;padding:6px 12px;border-radius:8px;font-family:monospace;font-size:14px;color:#007aff;display:inline-block;}
    .code{background:#1c1c1e;color:#fff;padding:16px;border-radius:12px;font-family:"SF Mono",Consolas,monospace;font-size:14px;line-height:1.5;margin:8px 0;overflow-x:auto;}
    .badge{background:#ff3b30;color:#fff;padding:4px 12px;border-radius:8px;font-size:13px;font-weight:600;display:inline-block;}
    .badge-success{background:#34c759;}
    .link{color:#007aff;text-decoration:none;font-weight:500;transition:opacity 0.2s;}
    .link:hover{opacity:0.7;}
    .success-banner{background:#34c759;color:#fff;padding:16px 24px;border-radius:12px;margin-bottom:24px;display:flex;align-items:center;gap:12px;animation:slideDown 0.3s ease-out;}
    .success-icon{font-size:20px;font-weight:700;}
    @keyframes slideDown{from{transform:translateY(-20px);opacity:0;}to{transform:translateY(0);opacity:1;}}
    .copy-feedback{position:fixed;top:50%;left:50%;transform:translate(-50%,-50%);background:#000;color:#fff;padding:16px 32px;border-radius:12px;font-size:16px;font-weight:500;opacity:0;pointer-events:none;transition:opacity 0.3s;z-index:9999;}
    .copy-feedback.show{opacity:0.9;}
    </style>

    <div class="wrap">
        <h1 class="settings-title">bKash SMS API Settings</h1>
        
        <div class="settings-wrap">
            <div class="section">
                <h2 class="section-title">API Configuration</h2>
                
                <div class="input-group">
                    <input type="text" value="<?php echo esc_attr($api_url); ?>" id="bkash_api_url" class="input" readonly>
                    <button class="c-button" onclick="bkashCopy('bkash_api_url', 'API Endpoint')">Copy URL</button>
                </div>
                
                <div class="input-group">
                    <input type="text" value="<?php echo esc_attr($api_key); ?>" id="bkash_api_key" class="input" readonly style="max-width:300px;">
                    <button class="c-button" onclick="bkashCopy('bkash_api_key', 'API Key')">Copy Key</button>
                </div>
                
                <form method="post" style="margin-top:20px;">
                    <input type="submit" class="c-button c-button-primary" name="bkash_generate_key" value="Generate New API Key">
                </form>
            </div>

            <div class="instructions">
                <h2 class="section-title">Setup Instructions</h2>
                <ol>
                    <li>
                        Download and install the <a href="https://github.com/bogkonstantin/android_income_sms_gateway_webhook/releases/" target="_blank" class="link">Forward SMS</a> app on your mobile device
                    </li>
                    <li>
                        Configure the following settings in the app:
                        <ul>
                            <li>
                                <span class="label">Sender:</span>
                                <span class="value">bKash</span>
                            </li>
                            <li>
                                <span class="label">Webhook URL:</span>
                                <div style="margin-top:8px;">
                                    <span class="value" style="word-break:break-all;"><?php echo esc_html($api_url); ?></span>
                                </div>
                            </li>
                            <li>
                                <span class="label">SIM Slot:</span>
                                Select your preferred SIM
                            </li>
                            <li>
                                <span class="label">JSON Payload Template:</span>
                                <div class="code">{<br>&nbsp;&nbsp;"message": "%text%"<br>}</div>
                            </li>
                            <li>
                                <span class="label">Headers:</span>
                                <div class="code">{"x-api-key": "<?php echo esc_html($api_key); ?>"}</div>
                            </li>
                            <li>
                                <span class="label">Number of retries:</span>
                                Set your preferred number
                            </li>
                        </ul>
                    </li>
                    <li>
                        Click "Test" - if it shows <span class="badge badge-success">Success</span> then Save the rule.
                    </li>
                </ol>
            </div>
        </div>
    </div>

    <div id="copy-feedback" class="copy-feedback"></div>

    <script>
    function bkashCopy(elementId, label) {
        var copyText = document.getElementById(elementId);
        copyText.select();
        copyText.setSelectionRange(0, 99999);
        navigator.clipboard.writeText(copyText.value).then(function() {
            var feedback = document.getElementById('copy-feedback');
            feedback.textContent = label + ' copied!';
            feedback.classList.add('show');
            setTimeout(function() {
                feedback.classList.remove('show');
            }, 2000);
        });
    }
    </script>
    <?php
}

// ===========================
// REST API for incoming SMS with API key authentication
// ===========================
add_action('rest_api_init', function () {
    register_rest_route('easypay/v1', '/sms', [
        'methods'  => 'POST',
        'callback' => 'easypay_bkash_sms_receiver',
        'permission_callback' => function ($request) {
            $api_key   = $request->get_header('x-api-key');
            $saved_key = get_option('bkash_sms_api_key');
            return $api_key && $saved_key && $api_key === $saved_key;
        }
    ]);
});