<?php
function bkash_woocommerce_settings_page() {
    if (!class_exists('WooCommerce')) {
        echo '<div class="error"><p>WooCommerce is required for this functionality.</p></div>';
        return;
    }
    if (!class_exists('pay_bKash')) {
        echo '<div class="error"><p>bKash payment gateway class not found.</p></div>';
        return;
    }
    global $current_section, $current_tab;
    $current_tab = 'checkout';
    $current_section = 'pay_bkash';
    $payment_gateways = WC()->payment_gateways->payment_gateways();
    if (!isset($payment_gateways['pay_bKash'])) {
        echo '<div class="error"><p>bKash payment gateway not found in WooCommerce.</p></div>';
        return;
    }
    $gateway = $payment_gateways['pay_bKash'];
    if (isset($_POST['save']) && wp_verify_nonce($_POST['_wpnonce'], 'woocommerce-settings')) {
        $gateway->process_admin_options();
        echo '<div class="success-notification"><span>Settings saved successfully</span></div>';
    }
    wp_enqueue_style('woocommerce_admin_styles');
    wp_enqueue_script('woocommerce_admin');
    wp_enqueue_script('wc-enhanced-select');
    wp_enqueue_media();
    ?>
<style>*{box-sizing:border-box}body{background:#f2f2f7;font-family:-apple-system,BlinkMacSystemFont,"Segoe UI",Roboto,Helvetica,Arial,sans-serif}.wrap{max-width:800px;margin:20px 0;padding:0}.settings-form{background:#fff;border-radius:12px;box-shadow:0 1px 3px rgba(0,0,0,0.04);overflow:hidden}.form-table{width:100%;border-collapse:collapse}.form-table tr{border-bottom:1px solid #e5e5ea}.form-table tr:last-child{border-bottom:none}.form-table th{padding:16px 20px;text-align:left;width:280px;vertical-align:top}.form-table th label{font-size:15px;font-weight:600;color:#000;display:block}.form-table td{padding:16px 20px;vertical-align:top}.form-table input[type="text"],.form-table input[type="email"],.form-table input[type="number"],.form-table input[type="password"],.form-table textarea,.form-table select{width:100%;max-width:400px;padding:12px 16px;border:1px solid #d1d1d6;border-radius:10px;font-size:15px;transition:all .2s;background:#f2f2f7}.form-table input[type="checkbox"]{width:20px;height:20px;cursor:pointer}.description{font-size:13px;color:#8e8e93;margin-top:6px;line-height:1.4}.toggle-switch{position:relative;display:inline-block;width:51px;height:31px}.toggle-switch input{opacity:0;width:0;height:0}.toggle-slider{position:absolute;cursor:pointer;top:0;left:0;right:0;bottom:0;background:#e5e5ea;transition:.3s;border-radius:31px}.toggle-slider:before{position:absolute;content:"";height:27px;width:27px;left:2px;bottom:2px;background:#fff;transition:.3s;border-radius:50%;box-shadow:0 2px 4px rgba(0,0,0,.2)}input:checked+.toggle-slider{background:#34c759}input:checked+.toggle-slider:before{transform:translateX(20px)}.submit-section{padding:20px;background:#f9f9fb;border-top:1px solid #e5e5ea}.success-notification{position:fixed;top:50px;right:20px;background:#34c759;color:#fff;padding:12px 20px;border-radius:10px;display:flex;align-items:center;font-size:15px;font-weight:500;animation:slideIn .3s ease-out;z-index:9999}.wrap .select2-container{max-width:400px!important}.wrap .select2-container .select2-selection--single{height:44px!important;border:1px solid #d1d1d6!important;border-radius:10px!important;background-color:#f2f2f7!important;padding:0!important}.wrap .select2-container .select2-selection__rendered{padding:12px 16px!important;line-height:20px!important;font-size:15px!important;color:#000!important}.wrap .select2-container .select2-selection__arrow{right:12px!important;top:50%!important;transform:translateY(-50%)!important}.select2-dropdown{border:1px solid #d1d1d6!important;border-radius:10px!important;margin-top:4px!important}.select2-results__option{padding:8px 16px!important;font-size:15px!important}.select2-results__option--highlighted{background-color:#007aff!important}@keyframes slideIn{from{transform:translateX(100%);opacity:0}to{transform:translateX(0);opacity:1}}.qr-upload-container{display:flex;align-items:center;gap:12px}.qr-preview{width:80px;height:80px;border-radius:10px;overflow:hidden;background:#f2f2f7;display:flex;align-items:center;justify-content:center;border:1px solid #e5e5ea}.qr-preview img{width:100%;height:100%;object-fit:cover}.upload-buttons{display:flex;gap:8px}.help-tip{display:inline-flex;align-items:center;justify-content:center;width:18px;height:18px;border-radius:50%;background:#007aff;color:#fff;font-size:12px;font-weight:600;margin-left:6px;cursor:help}@media(max-width:768px){.form-table th,.form-table td{display:block;width:100%;padding:12px 16px}.form-table th{padding-bottom:4px}.form-table td{padding-top:4px}}</style>
    <div class="wrap">
        <form method="post" id="mainform" action="" enctype="multipart/form-data" class="settings-form">
            <?php wp_nonce_field('woocommerce-settings'); ?>
            <div class="form-content">
                <?php $gateway->admin_options(); ?>
            </div>
            <div class="submit-section">
                <button type="submit" name="save" class="button-primary">
                    Save Changes
                </button>
            </div>
        </form>
    </div>
    <script>
    jQuery(document).ready(function($) {
        $('.form-table input[type="checkbox"]').each(function() {
            var checkbox = $(this);
            var wrapper = $('<label class="toggle-switch"></label>');
            var slider = $('<span class="toggle-slider"></span>');
            checkbox.wrap(wrapper);
            checkbox.after(slider);
        });
        if (typeof wc_enhanced_select_params !== 'undefined') {
            $('.wc-enhanced-select').selectWoo();
        }
        $('.woocommerce-help-tip').each(function() {
            $(this).replaceWith('<span class="help-tip" title="' + $(this).attr('data-tip') + '">?</span>');
        });
        $(document).on('click', '.bkash-upload-qr', function(e) {
            e.preventDefault();
            var button = $(this);
            var inputField = button.closest('.bkash-qr-upload-wrapper').find('input[type="text"]');
            var preview = button.closest('.bkash-qr-upload-wrapper').find('.bkash-qr-preview');
            var removeBtn = button.closest('.bkash-qr-upload-wrapper').find('.bkash-remove-qr');
            var frame = wp.media({
                title: 'Select QR Code Image',
                button: {text: 'Use This Image'},
                multiple: false,
                library: {type: 'image'}
            });
            frame.on('select', function() {
                var attachment = frame.state().get('selection').first().toJSON();
                inputField.val(attachment.url).trigger('change');
                preview.find('img').attr('src', attachment.url);
                preview.show();
                removeBtn.show();
            });
            frame.open();
        });
        $(document).on('click', '.bkash-remove-qr', function(e) {
            e.preventDefault();
            var button = $(this);
            var inputField = button.closest('.bkash-qr-upload-wrapper').find('input[type="text"]');
            var preview = button.closest('.bkash-qr-upload-wrapper').find('.bkash-qr-preview');
            inputField.val('').trigger('change');
            preview.hide();
            button.hide();
        });
        $('.success-notification').delay(3000).fadeOut(300, function() {
            $(this).remove();
        });
    });
    </script>
    <?php
}
function bkash_redirect_to_woocommerce_settings() {
    $redirect_url = admin_url('admin.php?page=wc-settings&tab=checkout&section=pay_bkash');
    wp_redirect($redirect_url);
    exit;
}
add_action('woocommerce_admin_field_bkash_custom_section', function($value) {
    ?>
    <tr valign="top">
        <th scope="row" class="titledesc">
            <label><?php echo esc_html($value['title']); ?></label>
        </th>
        <td class="forminp">
            <?php echo wp_kses_post($value['description']); ?>
        </td>
    </tr>
    <?php
});
?>